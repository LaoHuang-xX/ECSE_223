/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4262.30c9ffc7c modeling language!*/

package ca.mcgill.ecse223.block.model;
import java.io.Serializable;
import java.awt.geom.*;
import ca.mcgill.ecse223.block.model.BouncePoint.BounceDirection;
import java.util.*;

// line 25 "../../../../../Block223PlayMode.ump"
// line 107 "../../../../../Block223Persistence.ump"
// line 1 "../../../../../Block223States.ump"
public class PlayedGame implements Serializable
{

  //------------------------
  // STATIC VARIABLES
  //------------------------


  /**
   * at design time, the initial wait time may be adjusted as seen fit
   */
  public static final int INITIAL_WAIT_TIME = 1000;
  private static int nextId = 1;
  public static final int NR_LIVES = 3;

  /**
   * the PlayedBall and PlayedPaddle are not in a separate class to avoid the bug in Umple that occurred for the second constructor of Game
   * no direct link to Ball, because the ball can be found by navigating to PlayedGame, Game, and then Ball
   */
  public static final int BALL_INITIAL_X = Game.PLAY_AREA_SIDE / 2;
  public static final int BALL_INITIAL_Y = Game.PLAY_AREA_SIDE / 2;

  /**
   * no direct link to Paddle, because the paddle can be found by navigating to PlayedGame, Game, and then Paddle
   * pixels moved when right arrow key is pressed
   */
  public static final int PADDLE_MOVE_RIGHT = 1;

  /**
   * pixels moved when left arrow key is pressed
   */
  public static final int PADDLE_MOVE_LEFT = -1;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //PlayedGame Attributes
  private int score;
  private int lives;
  private int currentLevel;
  private double waitTime;
  private String playername;
  private double ballDirectionX;
  private double ballDirectionY;
  private double currentBallX;
  private double currentBallY;
  private double currentPaddleLength;
  private double currentPaddleX;
  private double currentPaddleY;

  //Autounique Attributes
  private int id;

  //PlayedGame State Machines
  public enum PlayStatus { Ready, Moving, Paused, GameOver }
  private PlayStatus playStatus;

  //PlayedGame Associations
  private Player player;
  private Game game;
  private List<PlayedBlockAssignment> blocks;
  private BouncePoint bounce;
  private Block223 block223;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public PlayedGame(String aPlayername, Game aGame, Block223 aBlock223)
  {
    // line 61 "../../../../../Block223PlayMode.ump"
    boolean didAddGameResult = setGame(aGame);
          if (!didAddGameResult)
          {
             throw new RuntimeException("Unable to create playedGame due to game");
          }
    // END OF UMPLE BEFORE INJECTION
    score = 0;
    lives = NR_LIVES;
    currentLevel = 1;
    waitTime = INITIAL_WAIT_TIME;
    playername = aPlayername;
    resetBallDirectionX();
    resetBallDirectionY();
    resetCurrentBallX();
    resetCurrentBallY();
    currentPaddleLength = getGame().getPaddle().getMaxPaddleLength();
    resetCurrentPaddleX();
    currentPaddleY = Game.PLAY_AREA_SIDE - Paddle.VERTICAL_DISTANCE - Paddle.PADDLE_WIDTH;
    id = nextId++;
    boolean didAddGame = setGame(aGame);
    if (!didAddGame)
    {
      throw new RuntimeException("Unable to create playedGame due to game");
    }
    blocks = new ArrayList<PlayedBlockAssignment>();
    boolean didAddBlock223 = setBlock223(aBlock223);
    if (!didAddBlock223)
    {
      throw new RuntimeException("Unable to create playedGame due to block223");
    }
    setPlayStatus(PlayStatus.Ready);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setScore(int aScore)
  {
    boolean wasSet = false;
    score = aScore;
    wasSet = true;
    return wasSet;
  }

  public boolean setLives(int aLives)
  {
    boolean wasSet = false;
    lives = aLives;
    wasSet = true;
    return wasSet;
  }

  public boolean setCurrentLevel(int aCurrentLevel)
  {
    boolean wasSet = false;
    currentLevel = aCurrentLevel;
    wasSet = true;
    return wasSet;
  }

  public boolean setWaitTime(double aWaitTime)
  {
    boolean wasSet = false;
    waitTime = aWaitTime;
    wasSet = true;
    return wasSet;
  }

  public boolean setPlayername(String aPlayername)
  {
    boolean wasSet = false;
    playername = aPlayername;
    wasSet = true;
    return wasSet;
  }
  /* Code from template attribute_SetDefaulted */
  public boolean setBallDirectionX(double aBallDirectionX)
  {
    boolean wasSet = false;
    ballDirectionX = aBallDirectionX;
    wasSet = true;
    return wasSet;
  }

  public boolean resetBallDirectionX()
  {
    boolean wasReset = false;
    ballDirectionX = getDefaultBallDirectionX();
    wasReset = true;
    return wasReset;
  }
  /* Code from template attribute_SetDefaulted */
  public boolean setBallDirectionY(double aBallDirectionY)
  {
    boolean wasSet = false;
    ballDirectionY = aBallDirectionY;
    wasSet = true;
    return wasSet;
  }

  public boolean resetBallDirectionY()
  {
    boolean wasReset = false;
    ballDirectionY = getDefaultBallDirectionY();
    wasReset = true;
    return wasReset;
  }
  /* Code from template attribute_SetDefaulted */
  public boolean setCurrentBallX(double aCurrentBallX)
  {
    boolean wasSet = false;
    currentBallX = aCurrentBallX;
    wasSet = true;
    return wasSet;
  }

  public boolean resetCurrentBallX()
  {
    boolean wasReset = false;
    currentBallX = getDefaultCurrentBallX();
    wasReset = true;
    return wasReset;
  }
  /* Code from template attribute_SetDefaulted */
  public boolean setCurrentBallY(double aCurrentBallY)
  {
    boolean wasSet = false;
    currentBallY = aCurrentBallY;
    wasSet = true;
    return wasSet;
  }

  public boolean resetCurrentBallY()
  {
    boolean wasReset = false;
    currentBallY = getDefaultCurrentBallY();
    wasReset = true;
    return wasReset;
  }

  public boolean setCurrentPaddleLength(double aCurrentPaddleLength)
  {
    boolean wasSet = false;
    currentPaddleLength = aCurrentPaddleLength;
    wasSet = true;
    return wasSet;
  }
  /* Code from template attribute_SetDefaulted */
  public boolean setCurrentPaddleX(double aCurrentPaddleX)
  {
    boolean wasSet = false;
    currentPaddleX = aCurrentPaddleX;
    wasSet = true;
    return wasSet;
  }

  public boolean resetCurrentPaddleX()
  {
    boolean wasReset = false;
    currentPaddleX = getDefaultCurrentPaddleX();
    wasReset = true;
    return wasReset;
  }

  public int getScore()
  {
    return score;
  }

  public int getLives()
  {
    return lives;
  }

  public int getCurrentLevel()
  {
    return currentLevel;
  }

  public double getWaitTime()
  {
    return waitTime;
  }

  /**
   * added here so that it only needs to be determined once
   */
  public String getPlayername()
  {
    return playername;
  }

  /**
   * 0/0 is the top left corner of the play area, i.e., a directionX/Y of 0/1 moves the ball down in a straight line
   */
  public double getBallDirectionX()
  {
    return ballDirectionX;
  }
  /* Code from template attribute_GetDefaulted */
  public double getDefaultBallDirectionX()
  {
    return getGame().getBall().getMinBallSpeedX();
  }

  public double getBallDirectionY()
  {
    return ballDirectionY;
  }
  /* Code from template attribute_GetDefaulted */
  public double getDefaultBallDirectionY()
  {
    return getGame().getBall().getMinBallSpeedY();
  }

  /**
   * the position of the ball is at the center of the ball
   */
  public double getCurrentBallX()
  {
    return currentBallX;
  }
  /* Code from template attribute_GetDefaulted */
  public double getDefaultCurrentBallX()
  {
    return BALL_INITIAL_X;
  }

  public double getCurrentBallY()
  {
    return currentBallY;
  }
  /* Code from template attribute_GetDefaulted */
  public double getDefaultCurrentBallY()
  {
    return BALL_INITIAL_Y;
  }

  public double getCurrentPaddleLength()
  {
    return currentPaddleLength;
  }

  /**
   * the position of the paddle is at its top right corner
   */
  public double getCurrentPaddleX()
  {
    return currentPaddleX;
  }
  /* Code from template attribute_GetDefaulted */
  public double getDefaultCurrentPaddleX()
  {
    return (Game.PLAY_AREA_SIDE - currentPaddleLength) / 2;
  }

  public double getCurrentPaddleY()
  {
    return currentPaddleY;
  }

  public int getId()
  {
    return id;
  }

  public String getPlayStatusFullName()
  {
    String answer = playStatus.toString();
    return answer;
  }

  public PlayStatus getPlayStatus()
  {
    return playStatus;
  }

  public boolean play()
  {
    boolean wasEventProcessed = false;
    
    PlayStatus aPlayStatus = playStatus;
    switch (aPlayStatus)
    {
      case Ready:
        setPlayStatus(PlayStatus.Moving);
        wasEventProcessed = true;
        break;
      case Paused:
        setPlayStatus(PlayStatus.Moving);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean pause()
  {
    boolean wasEventProcessed = false;
    
    PlayStatus aPlayStatus = playStatus;
    switch (aPlayStatus)
    {
      case Moving:
        setPlayStatus(PlayStatus.Paused);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean move()
  {
    boolean wasEventProcessed = false;
    
    PlayStatus aPlayStatus = playStatus;
    switch (aPlayStatus)
    {
      case Moving:
        if (hitPaddle())
        {
        // line 13 "../../../../../Block223States.ump"
          doHitPaddleOrWall();
          setPlayStatus(PlayStatus.Moving);
          wasEventProcessed = true;
          break;
        }
        if (isOutOfBoundsAndLastLife())
        {
        // line 14 "../../../../../Block223States.ump"
          doOutOfBounds();
          setPlayStatus(PlayStatus.GameOver);
          wasEventProcessed = true;
          break;
        }
        if (isOutOfBounds())
        {
        // line 15 "../../../../../Block223States.ump"
          doOutOfBounds();
          setPlayStatus(PlayStatus.Paused);
          wasEventProcessed = true;
          break;
        }
        if (hitLastBlockAndLastLevel())
        {
        // line 16 "../../../../../Block223States.ump"
          doHitBlock();
          setPlayStatus(PlayStatus.GameOver);
          wasEventProcessed = true;
          break;
        }
        if (hitLastBlock())
        {
        // line 17 "../../../../../Block223States.ump"
          doHitBlockNextLevel();
          setPlayStatus(PlayStatus.Ready);
          wasEventProcessed = true;
          break;
        }
        if (hitBlock())
        {
        // line 18 "../../../../../Block223States.ump"
          doHitBlock();
          setPlayStatus(PlayStatus.Moving);
          wasEventProcessed = true;
          break;
        }
        if (hitWall())
        {
        // line 19 "../../../../../Block223States.ump"
          doHitPaddleOrWall();
          setPlayStatus(PlayStatus.Moving);
          wasEventProcessed = true;
          break;
        }
        // line 20 "../../../../../Block223States.ump"
        doHitNothingAndNotOutOfBounds();
        setPlayStatus(PlayStatus.Moving);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private void setPlayStatus(PlayStatus aPlayStatus)
  {
    playStatus = aPlayStatus;

    // entry actions and do activities
    switch(playStatus)
    {
      case Ready:
        // line 8 "../../../../../Block223States.ump"
        doSetup();
        break;
      case GameOver:
        // line 26 "../../../../../Block223States.ump"
        doGameOver();
        break;
    }
  }
  /* Code from template association_GetOne */
  public Player getPlayer()
  {
    return player;
  }

  public boolean hasPlayer()
  {
    boolean has = player != null;
    return has;
  }
  /* Code from template association_GetOne */
  public Game getGame()
  {
    return game;
  }
  /* Code from template association_GetMany */
  public PlayedBlockAssignment getBlock(int index)
  {
    PlayedBlockAssignment aBlock = blocks.get(index);
    return aBlock;
  }

  public List<PlayedBlockAssignment> getBlocks()
  {
    List<PlayedBlockAssignment> newBlocks = Collections.unmodifiableList(blocks);
    return newBlocks;
  }

  public int numberOfBlocks()
  {
    int number = blocks.size();
    return number;
  }

  public boolean hasBlocks()
  {
    boolean has = blocks.size() > 0;
    return has;
  }

  public int indexOfBlock(PlayedBlockAssignment aBlock)
  {
    int index = blocks.indexOf(aBlock);
    return index;
  }
  /* Code from template association_GetOne */
  public BouncePoint getBounce()
  {
    return bounce;
  }

  public boolean hasBounce()
  {
    boolean has = bounce != null;
    return has;
  }
  /* Code from template association_GetOne */
  public Block223 getBlock223()
  {
    return block223;
  }
  /* Code from template association_SetOptionalOneToMany */
  public boolean setPlayer(Player aPlayer)
  {
    boolean wasSet = false;
    Player existingPlayer = player;
    player = aPlayer;
    if (existingPlayer != null && !existingPlayer.equals(aPlayer))
    {
      existingPlayer.removePlayedGame(this);
    }
    if (aPlayer != null)
    {
      aPlayer.addPlayedGame(this);
    }
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_SetOneToMany */
  public boolean setGame(Game aGame)
  {
    boolean wasSet = false;
    if (aGame == null)
    {
      return wasSet;
    }

    Game existingGame = game;
    game = aGame;
    if (existingGame != null && !existingGame.equals(aGame))
    {
      existingGame.removePlayedGame(this);
    }
    game.addPlayedGame(this);
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfBlocks()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public PlayedBlockAssignment addBlock(int aX, int aY, Block aBlock)
  {
    return new PlayedBlockAssignment(aX, aY, aBlock, this);
  }

  public boolean addBlock(PlayedBlockAssignment aBlock)
  {
    boolean wasAdded = false;
    if (blocks.contains(aBlock)) { return false; }
    PlayedGame existingPlayedGame = aBlock.getPlayedGame();
    boolean isNewPlayedGame = existingPlayedGame != null && !this.equals(existingPlayedGame);
    if (isNewPlayedGame)
    {
      aBlock.setPlayedGame(this);
    }
    else
    {
      blocks.add(aBlock);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeBlock(PlayedBlockAssignment aBlock)
  {
    boolean wasRemoved = false;
    //Unable to remove aBlock, as it must always have a playedGame
    if (!this.equals(aBlock.getPlayedGame()))
    {
      blocks.remove(aBlock);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addBlockAt(PlayedBlockAssignment aBlock, int index)
  {  
    boolean wasAdded = false;
    if(addBlock(aBlock))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfBlocks()) { index = numberOfBlocks() - 1; }
      blocks.remove(aBlock);
      blocks.add(index, aBlock);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveBlockAt(PlayedBlockAssignment aBlock, int index)
  {
    boolean wasAdded = false;
    if(blocks.contains(aBlock))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfBlocks()) { index = numberOfBlocks() - 1; }
      blocks.remove(aBlock);
      blocks.add(index, aBlock);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addBlockAt(aBlock, index);
    }
    return wasAdded;
  }
  /* Code from template association_SetUnidirectionalOptionalOne */
  public boolean setBounce(BouncePoint aNewBounce)
  {
    boolean wasSet = false;
    bounce = aNewBounce;
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_SetOneToMany */
  public boolean setBlock223(Block223 aBlock223)
  {
    boolean wasSet = false;
    if (aBlock223 == null)
    {
      return wasSet;
    }

    Block223 existingBlock223 = block223;
    block223 = aBlock223;
    if (existingBlock223 != null && !existingBlock223.equals(aBlock223))
    {
      existingBlock223.removePlayedGame(this);
    }
    block223.addPlayedGame(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    if (player != null)
    {
      Player placeholderPlayer = player;
      this.player = null;
      placeholderPlayer.removePlayedGame(this);
    }
    Game placeholderGame = game;
    this.game = null;
    if(placeholderGame != null)
    {
      placeholderGame.removePlayedGame(this);
    }
    while (blocks.size() > 0)
    {
      PlayedBlockAssignment aBlock = blocks.get(blocks.size() - 1);
      aBlock.delete();
      blocks.remove(aBlock);
    }
    
    bounce = null;
    Block223 placeholderBlock223 = block223;
    this.block223 = null;
    if(placeholderBlock223 != null)
    {
      placeholderBlock223.removePlayedGame(this);
    }
  }

  // line 113 "../../../../../Block223Persistence.ump"
   public static  void reinitializeAutouniqueId(List<PlayedGame> games){
    nextId = 0;
    for (PlayedGame g : games) {
        if (g.getId() > nextId) {
          nextId = g.getId();
        }
    }
    nextId++;
    System.out.println("Next block ID = " + nextId);
  }


  /**
   * Guards
   */
  // line 33 "../../../../../Block223States.ump"
   private boolean hitPaddle(){
    BouncePoint bp = calculateBouncePointPaddle();
    setBounce(bp);
    return getBounce() != null;
  }

  // line 39 "../../../../../Block223States.ump"
   private boolean isOutOfBoundsAndLastLife(){
    // boolean outOfBounds = false;
    // if (lives == 1){
    //   outOfBounds = isOutOfBounds();
    // }
    return isOutOfBounds() && lives == 1;
  }

  // line 47 "../../../../../Block223States.ump"
   private boolean isOutOfBounds(){
    // boolean outOfBounds = false;
    double y = getCurrentBallY();
    double dy = getBallDirectionY();
    // Game game = getGame();
    // Ball ball = game.getBall();
    return y + Ball.BALL_DIAMETER/2 + dy > Game.PLAY_AREA_SIDE;
  }

  // line 56 "../../../../../Block223States.ump"
   private boolean hitLastBlockAndLastLevel(){
    // Game pgame = this.getGame();
		// int nrLevels = pgame.numberOfLevels();
		// this.setBounce(null);
		// if(nrLevels == currentLevel) {
		// 	int nrBlocks = this.numberOfBlocks();
		// 	if(nrBlocks == 1){
		// 		PlayedBlockAssignment block = this.getBlock(0);
		// 		BouncePoint bp = this.calculateBouncePointBlock(block);
		// 		if (bp != null) {
		// 			setBounce(bp);
		// 			return true;
		// 		}
		// 	}
		// 	//here might be an exception
		// }
    // return false;
    Game game = this.getGame();
    if (currentLevel == game.numberOfLevels() && numberOfBlocks() == 1) {
      BouncePoint bp = calculateBouncePointBlock(blocks.get(0));
      setBounce(bp);
      return getBounce() != null;
    }
    return false;
  }

  // line 82 "../../../../../Block223States.ump"
   private boolean hitLastBlock(){
    // int nrBlocks = this.numberOfBlocks();
    // this.setBounce(null);
    if(numberOfBlocks() == 1) {
      BouncePoint bp = calculateBouncePointBlock(blocks.get(0));
      setBounce(bp);
      return getBounce() != null;
    }
    return false;
  }

  // line 93 "../../../../../Block223States.ump"
   private boolean hitBlock(){
    // int nrBlocks = this.numberOfBlocks();
    this.setBounce(null);
    for(int i = 0; i < blocks.size(); i++){
      BouncePoint bp = calculateBouncePointBlock(blocks.get(i));
      // BouncePoint bounce = this.getBounce();
      // boolean closer = isCloser(bp, bounce);
      // if(closer){
      //   this.setBounce(bp);
      // }
      if (bp != null) {
        setBounce(bp);
        return true;
      }
    }
    return false;
  }

  // line 111 "../../../../../Block223States.ump"
   private boolean hitWall(){
    BouncePoint bp = calculateBouncePointWall();
    setBounce(bp);
    return getBounce() != null;
  }


  /**
   * Actions
   */
  // line 119 "../../../../../Block223States.ump"
   private void doSetup(){
    resetCurrentBallX();
    resetCurrentBallY();
    resetBallDirectionX();
    resetBallDirectionY();
    resetCurrentPaddleX();
    Game g = getGame();
    Level l = g.getLevel(currentLevel -1);
    
    for (BlockAssignment ba : l.getBlockAssignments()) {
      new PlayedBlockAssignment(Game.WALL_PADDING + (Block.SIZE + Game.COLUMNS_PADDING) * (ba.getGridHorizontalPosition() - 1),
        Game.WALL_PADDING + (Block.SIZE + Game.ROW_PADDING) * ba.getGridVerticalPosition() - 1,
        ba.getBlock(), this);
    }
    outerloop: while (numberOfBlocks() < game.getNrBlocksPerLevel()) { 
      int randX = (int) (Math.random() * 15) + 1;
      int randY = (int) (Math.random() * 9) + 1;

      int coordX = Game.WALL_PADDING + (Block.SIZE + Game.COLUMNS_PADDING) * (randX - 1);
      int coordY = Game.WALL_PADDING + (Block.SIZE + Game.ROW_PADDING) * (randY - 1);

      for (PlayedBlockAssignment pba : blocks) {
        if (pba.getX() == coordX && pba.getY() == coordY) {
          continue outerloop;
        }
      }
      new PlayedBlockAssignment(coordX, coordY, g.getRandomBlock(), this);
    }
  }

  // line 149 "../../../../../Block223States.ump"
   private void doHitPaddleOrWall(){
    bounceBall();
  }

  // line 153 "../../../../../Block223States.ump"
   private void doOutOfBounds(){
    setLives(lives - 1);
    resetCurrentBallX();
    resetCurrentBallY();
    resetBallDirectionX();
    resetBallDirectionY();
    resetCurrentPaddleX();
  }

  // line 162 "../../../../../Block223States.ump"
   private void doHitBlock(){
    int score = getScore();
    BouncePoint bounce = getBounce();
    PlayedBlockAssignment pblock = bounce.getHitBlock();
    Block block = pblock.getBlock();
    int bscore = block.getPoints();
    setScore(bscore + score);
    pblock.delete();
    bounceBall();
  }

  // line 173 "../../../../../Block223States.ump"
   private void doHitBlockNextLevel(){
    doHitBlock();
    int level = getCurrentLevel();
    setCurrentLevel(level+1);
    double maxPL = (double) getGame().getPaddle().getMaxPaddleLength();
    double minPL = (double) getGame().getPaddle().getMinPaddleLength(); 
    double numLevels = (double) getGame().numberOfLevels();
    setCurrentPaddleLength(maxPL - (maxPL - minPL) / (numLevels-1) * (getCurrentLevel() - 1));
    setWaitTime(INITIAL_WAIT_TIME * Math.pow(getGame().getBall().getBallSpeedIncreaseFactor(), (getCurrentLevel() - 1)));
  }

  // line 184 "../../../../../Block223States.ump"
   private void doHitNothingAndNotOutOfBounds(){
    double x = getCurrentBallX();
    double y = getCurrentBallY();
    double dx = getBallDirectionX();
    double dy = getBallDirectionY();
    setCurrentBallX(x + dx);
    setCurrentBallY(y + dy);
  }

  // line 193 "../../../../../Block223States.ump"
   private void bounceBall(){
    //update ball position and direction
    System.out.println("Bouncing ball");
    double cbx = getCurrentBallX();
    double cby = getCurrentBallY();
    double dx = getBallDirectionX();
    double dy = getBallDirectionY();
    
    BouncePoint bp = getBounce();
    
    double bpx = bp.getX();
    double bpy = bp.getY();
    System.out.println("BouncePoint: " + bpx + ", " + bpy);

    double maxdist = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
    double disttobounce = Math.sqrt(Math.pow(cbx - bpx, 2) + Math.pow(cby - bpy, 2));
    double rem = maxdist - disttobounce;
    if (rem == 0.0) {
      setCurrentBallX(bpx);
      setCurrentBallY(bpy);
      return;
    }
    dx = dx * rem / maxdist;
    dy = dy * rem / maxdist;

    cbx = bpx;
    cby = bpy;

		if(bp.getDirection() == BounceDirection.FLIP_X){
      dx = -dx;
      setBallDirectionX(getBallDirectionX() * -1.0);          
      setBallDirectionY(getBallDirectionY() + (getBallDirectionY() < 0 ? -1.0 : 1.0) * 0.1 * Math.abs(getBallDirectionX()));
		}
		else if(bp.getDirection() == BounceDirection.FLIP_Y){
      dy = -dy;
      setBallDirectionY(getBallDirectionY() * -1.0);
      setBallDirectionX(getBallDirectionX() + (getBallDirectionX() < 0 ? -1.0 : 1.0) * 0.1 * Math.abs(getBallDirectionY()));
    }
    else if(bp.getDirection() == BounceDirection.FLIP_BOTH){
      dx = -dx;
      dy = -dy;
      setBallDirectionX(getBallDirectionX() * -1.0);
      setBallDirectionY(getBallDirectionY() * -1.0);
    }
    
    cbx = cbx + dx;
    cby = cby + dy;

    System.out.println("Moving ball to " + cbx + ", " + cby);
    setCurrentBallX(cbx);
    setCurrentBallY(cby);
  }

  // line 246 "../../../../../Block223States.ump"
   private void doGameOver(){
    Block223 block223 = getBlock223();
    Player p = getPlayer();

    if (p != null){
      Game game = getGame();
      HallOfFameEntry hof = new HallOfFameEntry(score, playername, p, game, block223);
      game.setMostRecentEntry(hof);
    }

    this.delete();
  }

  // line 259 "../../../../../Block223States.ump"
   private BouncePoint calculateBouncePointBlock(PlayedBlockAssignment pb){
    double diam = Ball.BALL_DIAMETER;
    double radius = Ball.BALL_DIAMETER / 2;
    
    double width = pb.getX() + Block.SIZE;
    double height = pb.getY() + Block.SIZE;
    
    Arc2D tl = new Arc2D.Double(pb.getX() - radius, pb.getY() - radius, diam, diam, 90, 90, Arc2D.OPEN);
    Arc2D tr = new Arc2D.Double(width - radius, pb.getY() - radius, diam, diam, 0, 90, Arc2D.OPEN);
    Arc2D bl = new Arc2D.Double(pb.getX() - radius, height - radius, diam, diam, 180, 90, Arc2D.OPEN);
    Arc2D br = new Arc2D.Double(width - radius, height - radius, diam, diam, 270, 90, Arc2D.OPEN);

    Line2D top = new Line2D.Double(pb.getX(), pb.getY() - radius, width, pb.getY() - radius);
    Line2D left = new Line2D.Double(pb.getX() - radius, pb.getY(), pb.getX() - radius, height);
    Line2D bottom = new Line2D.Double(pb.getX(), height + radius, width, height+radius);
    Line2D right = new Line2D.Double(width + radius, pb.getY(), width + radius, height);

    Line2D ballpath = new Line2D.Double(currentBallX, currentBallX+ballDirectionX, currentBallY, currentBallY+ballDirectionY);
    
    //Check line intersects each section
		Point2D topint = calculateIntersection(ballpath,top);
		Point2D botint = calculateIntersection(ballpath,bottom);
		Point2D leftint = calculateIntersection(ballpath,left);
		Point2D rightint = calculateIntersection(ballpath,right);
		if (topint != null) {
			BouncePoint bp = new BouncePoint(topint.getX(), topint.getY(), BounceDirection.FLIP_Y);
      bp.setHitBlock(pb);
      return bp;
		}
		else if(botint != null){
			BouncePoint bp = new BouncePoint(botint.getX(), botint.getY(), BounceDirection.FLIP_Y);
      bp.setHitBlock(pb);
      return bp;
		} 
		else if (leftint != null) {
			BouncePoint bp = new BouncePoint(leftint.getX(), leftint.getY(), BounceDirection.FLIP_X);
      bp.setHitBlock(pb);
      return bp;
		}
		else if (rightint != null) {
			BouncePoint bp = new BouncePoint(rightint.getX(), rightint.getY(), BounceDirection.FLIP_X);
      bp.setHitBlock(pb);
      return bp;
		}

		//collide on corners
		Point2D tlintersects = calculateIntersection(ballpath,tl);
		Point2D trintersects = calculateIntersection(ballpath,tr);
		Point2D brintersects = calculateIntersection(ballpath,br);
		Point2D blintersects = calculateIntersection(ballpath,bl);

		if(tlintersects!=null){
			BouncePoint bp = new BouncePoint(tlintersects.getX(), tlintersects.getY(), BounceDirection.FLIP_BOTH);
      bp.setHitBlock(pb);
      return bp;
		}
		else if(trintersects!=null){
			BouncePoint bp = new BouncePoint(trintersects.getX(), trintersects.getY(), BounceDirection.FLIP_BOTH);
      bp.setHitBlock(pb);
      return bp;
		}
		else if(brintersects!=null){
			BouncePoint bp = new BouncePoint(brintersects.getX(), brintersects.getY(), BounceDirection.FLIP_BOTH);
      bp.setHitBlock(pb);
      return bp;
		}
		else if(blintersects!=null){
			BouncePoint bp = new BouncePoint(blintersects.getX(), blintersects.getY(), BounceDirection.FLIP_BOTH);
      bp.setHitBlock(pb);
      return bp;
		}

    return null;
  }

  // line 335 "../../../../../Block223States.ump"
   private BouncePoint calculateBouncePointWall(){
    double cbx = getCurrentBallX();
		double cby = getCurrentBallY();
		double dx = getBallDirectionX();
		double dy = getBallDirectionY();
		double newBallX = cbx + dx;
		double newBallY = cby + dy;
    double radius = Ball.BALL_DIAMETER/2;
    
    Line2D ballPath = new Line2D.Double(cbx, cby, newBallX, newBallY);
    
    Line2D left = new Line2D.Double(radius, radius, radius, Game.PLAY_AREA_SIDE - radius);
    Line2D right = new Line2D.Double(Game.PLAY_AREA_SIDE - radius, radius, Game.PLAY_AREA_SIDE - radius, Game.PLAY_AREA_SIDE - radius);
    Line2D top = new Line2D.Double(radius, radius, Game.PLAY_AREA_SIDE - radius, radius);

    List<BouncePoint> bpts = new ArrayList<>();

    Point2D intleft = calculateIntersection(ballPath, left);
    Point2D intright = calculateIntersection(ballPath, right);
    Point2D inttop = calculateIntersection(ballPath, top);

    if (intleft != null) {
      bpts.add(new BouncePoint(intleft.getX(), intleft.getY(), BounceDirection.FLIP_X));
    }
    if (intright != null) {
      bpts.add(new BouncePoint(intright.getX(), intright.getY(), BounceDirection.FLIP_X));
    }
    if (inttop != null) {
      bpts.add(new BouncePoint(inttop.getX(), inttop.getY(), BounceDirection.FLIP_Y));
    }
    
    if (bpts.size() == 0) {
      return null;
    }
    if (bpts.size() == 1) {
      return bpts.get(0);
    } 
    
    return new BouncePoint(bpts.get(0).getX(), bpts.get(0).getY(), BounceDirection.FLIP_BOTH);
  }


  /**
   * BouncePoint areaA = new BouncePoint(0,0,null);
   * BouncePoint areaB = new BouncePoint(0,0,null);
   * BouncePoint areaC = new BouncePoint(0,0,null);
   * ArrayList<BouncePoint> check = new ArrayList<BouncePoint>();
   * step 1
   * create 3 rectangle for intersection check
   * Rectangle2D rectangleLeft = new Rectangle2D.Double(0,0,radius,Game.PLAY_AREA_SIDE-radius);
   * Rectangle2D rectangleRight = new Rectangle2D.Double(Game.PLAY_AREA_SIDE-radius,0,radius,Game.PLAY_AREA_SIDE-radius);
   * Rectangle2D rectangleTop = new Rectangle2D.Double(radius,0,Game.PLAY_AREA_SIDE-Ball.BALL_DIAMETER,radius);
   * if((rectangleLeft.intersectsLine(currentBallX, currentBallY, newBallX, newBallY)==false)&&
   * (rectangleRight.intersectsLine(currentBallX, currentBallY, newBallX, newBallY)==false)
   * &&(rectangleTop.intersectsLine(currentBallX, currentBallY, newBallX, newBallY)==false)) {
   * return null;
   * }
   * else {
   * areaA.setX(getLineSegmentIntersectionX(currentBallX,currentBallY,newBallX,newBallY,radius,0,radius,Game.PLAY_AREA_SIDE-radius));
   * areaA.setY(getLineSegmentIntersectionY(currentBallX,currentBallY,newBallX,newBallY,radius,0,radius,Game.PLAY_AREA_SIDE-radius));
   * areaA.setDirection(getLineIntersectionBounceDirectionWall(currentBallX,currentBallY,newBallX,newBallY,radius,0,radius,Game.PLAY_AREA_SIDE-radius));
   * areaB.setX(getLineSegmentIntersectionX(currentBallX,currentBallY,newBallX,newBallY,radius,radius,Game.PLAY_AREA_SIDE-radius,radius));
   * areaB.setY(getLineSegmentIntersectionY(currentBallX,currentBallY,newBallX,newBallY,radius,radius,Game.PLAY_AREA_SIDE-radius,radius));
   * areaB.setDirection(getLineIntersectionBounceDirectionWall(currentBallX,currentBallY,newBallX,newBallY,radius,radius,Game.PLAY_AREA_SIDE-radius,radius));
   * areaC.setX(getLineSegmentIntersectionX(currentBallX,currentBallY,newBallX,newBallY,Game.PLAY_AREA_SIDE-radius,radius,Game.PLAY_AREA_SIDE-radius,Game.PLAY_AREA_SIDE-radius));
   * areaC.setY(getLineSegmentIntersectionY(currentBallX,currentBallY,newBallX,newBallY,Game.PLAY_AREA_SIDE-radius,radius,Game.PLAY_AREA_SIDE-radius,Game.PLAY_AREA_SIDE-radius));
   * areaC.setDirection(getLineIntersectionBounceDirectionWall(currentBallX,currentBallY,newBallX,newBallY,Game.PLAY_AREA_SIDE-radius,radius,Game.PLAY_AREA_SIDE-radius,Game.PLAY_AREA_SIDE-radius));
   * check.add(areaA);
   * check.add(areaB);
   * check.add(areaC);
   * ArrayList<BouncePoint> potentialBouncePoint = new ArrayList<BouncePoint>();
   * for(int i=0;i<3;i++) {
   * if(check.get(i).getX() != 0 || check.get(i).getX() != 0) {
   * potentialBouncePoint.add(check.get(i));
   * }
   * }
   * if(potentialBouncePoint.get(0) == null) {
   * return null;
   * }
   * else if(potentialBouncePoint.get(0) != null && potentialBouncePoint.get(1) == null) {
   * bp = potentialBouncePoint.get(0);
   * }
   * else if(isCloser(potentialBouncePoint.get(0),potentialBouncePoint.get(1))==true) {
   * bp = potentialBouncePoint.get(0);
   * }
   * else {
   * bp = potentialBouncePoint.get(1);
   * }
   * }
   * // BouncePoint bp = new BouncePoint(bounceX, bounceY, direction);
   * return bp;
   * // error, still needs to change
   * // return null;
   * }
   */
  // line 437 "../../../../../Block223States.ump"
   private BouncePoint calculateBouncePointPaddle(){
    double cpx = getCurrentPaddleX();
    double cpy = getCurrentPaddleY();
    double cpl = getCurrentPaddleLength();
    double cbx = getCurrentBallX();
    double cby = getCurrentBallY();
    double dx = getBallDirectionX();
    double dy = getBallDirectionY();
    double newBallX = cbx + dx;
    double newBallY = cby + dy;
    double radius = Ball.BALL_DIAMETER / 2;

    Line2D ballPath = new Line2D.Double(cbx, cby, newBallX, newBallY);

    Line2D left = new Line2D.Double(cpx - radius, cpy, cpx - radius, cpy + Paddle.PADDLE_WIDTH);
    Line2D top = new Line2D.Double(cpx, cpy - radius, cpx + cpl, cpy - radius);
    Line2D right = new Line2D.Double(cpx + cpl, cpy, cpx + cpl, cpy + Paddle.PADDLE_WIDTH);

    Arc2D tl = new Arc2D.Double(cpx - radius, cpy - radius, radius * 2, radius * 2, 90, 90, Arc2D.OPEN);
    Arc2D tr = new Arc2D.Double(cpx + cpl - radius, cpy - radius, radius * 2, radius * 2, 0, 90, Arc2D.OPEN);    

    Point2D leftint = calculateIntersection(ballPath, left);
    Point2D topint = calculateIntersection(ballPath, top);
    Point2D rightint = calculateIntersection(ballPath, right);

    Point2D tlint = calculateIntersection(ballPath, tl);
    Point2D trint = calculateIntersection(ballPath, tr);

    if (leftint != null) {
      return new BouncePoint(leftint.getX(), leftint.getY(), BounceDirection.FLIP_X);
    }
    if (topint != null) {
      return new BouncePoint(topint.getX(), topint.getY(), BounceDirection.FLIP_Y);
    }
    if (rightint != null) {
      return new BouncePoint(rightint.getX(), rightint.getY(), BounceDirection.FLIP_X);
    }

    if (tlint != null) {
      if (cbx < tlint.getX()) {
        return new BouncePoint(tlint.getX(), tlint.getY(), BounceDirection.FLIP_X);
      } else {
        return new BouncePoint(tlint.getX(), tlint.getY(), BounceDirection.FLIP_Y);
      }
    }

    if (trint != null) {
      if (cbx > trint.getX()) {
        return new BouncePoint(trint.getX(), trint.getY(), BounceDirection.FLIP_X);
      } else {
        return new BouncePoint(trint.getX(), trint.getY(), BounceDirection.FLIP_Y);
      }
    }
    return null;
  }


  /**
   * BouncePoint areaA = new BouncePoint(0, 0, null);
   * BouncePoint areaB = new BouncePoint(0, 0, null);
   * BouncePoint areaC = new BouncePoint(0, 0, null);
   * BouncePoint areaE = new BouncePoint(0, 0, null);
   * BouncePoint areaF = new BouncePoint(0, 0, null);
   * ArrayList<BouncePoint> check = new ArrayList<BouncePoint>();
   * // step 1
   * // create a rectangle for intersection check
   * Rectangle2D rectangle = new Rectangle2D.Double(currentPaddleX - radius, currentPaddleY - radius,
   * currentPaddleLength + 2 * radius, Paddle.PADDLE_WIDTH + radius);
   * if ((rectangle.intersectsLine(currentBallX, currentBallY, newBallX, newBallY) == false)
   * && (rectangle.intersectsLine(currentBallX, currentBallY, newBallX, newBallY) == false)
   * && (rectangle.intersectsLine(currentBallX, currentBallY, newBallX, newBallY) == false)) {
   * return null;
   * } else {
   * areaA.setX(getLineSegmentIntersectionX(currentBallX, currentBallY, newBallX, newBallY, currentPaddleX,
   * currentPaddleY - radius, currentPaddleX + currentPaddleLength, currentPaddleY - radius));
   * areaA.setY(getLineSegmentIntersectionY(currentBallX, currentBallY, newBallX, newBallY, currentPaddleX,
   * currentPaddleY - radius, currentPaddleX + currentPaddleLength, currentPaddleY - radius));
   * areaA.setDirection(getLineIntersectionBounceDirectionPaddle(currentBallX, currentBallY, newBallX, newBallY,
   * currentPaddleX, currentPaddleY - radius, currentPaddleX + currentPaddleLength, currentPaddleY - radius));
   * areaB.setX(getLineSegmentIntersectionX(currentBallX, currentBallY, newBallX, newBallY, currentPaddleX - radius,
   * currentPaddleY, currentPaddleX - radius, currentPaddleY + Paddle.PADDLE_WIDTH));
   * areaB.setY(getLineSegmentIntersectionY(currentBallX, currentBallY, newBallX, newBallY, currentPaddleX - radius,
   * currentPaddleY, currentPaddleX - radius, currentPaddleY + Paddle.PADDLE_WIDTH));
   * areaB.setDirection(getLineIntersectionBounceDirectionPaddle(currentBallX, currentBallY, newBallX, newBallY,
   * currentPaddleX - radius, currentPaddleY, currentPaddleX - radius, currentPaddleY + Paddle.PADDLE_WIDTH));
   * areaC.setX(getLineSegmentIntersectionX(currentBallX, currentBallY, newBallX, newBallY,
   * currentPaddleX + currentPaddleLength + radius, currentPaddleY, currentPaddleX + currentPaddleLength + radius,
   * currentPaddleY + Paddle.PADDLE_WIDTH));
   * areaC.setY(getLineSegmentIntersectionY(currentBallX, currentBallY, newBallX, newBallY,
   * currentPaddleX + currentPaddleLength + radius, currentPaddleY, currentPaddleX + currentPaddleLength + radius,
   * currentPaddleY + Paddle.PADDLE_WIDTH));
   * areaC.setDirection(getLineIntersectionBounceDirectionPaddle(currentBallX, currentBallY, newBallX, newBallY,
   * currentPaddleX + currentPaddleLength + radius, currentPaddleY, currentPaddleX + currentPaddleLength + radius,
   * currentPaddleY + Paddle.PADDLE_WIDTH));
   * areaE.setX(getLineArcIntersectionX(currentBallX, currentBallY, newBallX, newBallY, currentPaddleX - radius,
   * currentPaddleY, currentPaddleX, currentPaddleY - radius));
   * areaE.setY(getLineArcIntersectionY(currentBallX, currentBallY, newBallX, newBallY, currentPaddleX - radius,
   * currentPaddleY, currentPaddleX, currentPaddleY - radius));
   * areaE.setDirection(getArcIntersectionBounceDirectionPaddleLeft(currentBallX, currentBallY, newBallX, newBallY,
   * currentPaddleX - radius, currentPaddleY, currentPaddleX, currentPaddleY - radius));
   * areaF.setX(getLineArcIntersectionX(currentBallX, currentBallY, newBallX, newBallY,
   * currentPaddleX + currentPaddleLength + radius, currentPaddleY, currentPaddleX + currentPaddleLength,
   * currentPaddleY - radius));
   * areaF.setY(getLineArcIntersectionY(currentBallX, currentBallY, newBallX, newBallY,
   * currentPaddleX + currentPaddleLength + radius, currentPaddleY, currentPaddleX + currentPaddleLength,
   * currentPaddleY - radius));
   * areaF.setDirection(getArcIntersectionBounceDirectionPaddleRight(currentBallX, currentBallY, newBallX, newBallY,
   * currentPaddleX + currentPaddleLength + radius, currentPaddleY, currentPaddleX + currentPaddleLength,
   * currentPaddleY - radius));
   * check.add(areaA);
   * check.add(areaB);
   * check.add(areaC);
   * check.add(areaE);
   * check.add(areaF);
   * ArrayList<BouncePoint> potentialBouncePoint = new ArrayList<BouncePoint>();
   * for (int i = 0; i < 5; i++) {
   * if (check.get(i).getX() != 0 || check.get(i).getX() != 0) {
   * potentialBouncePoint.add(check.get(i));
   * }
   * }
   * if (potentialBouncePoint.get(0) == null) {
   * return null;
   * } else if (potentialBouncePoint.get(0) != null && potentialBouncePoint.get(1) == null) {
   * bp = potentialBouncePoint.get(0);
   * } else if (isCloser(potentialBouncePoint.get(0), potentialBouncePoint.get(1)) == true) {
   * bp = potentialBouncePoint.get(0);
   * } else {
   * bp = potentialBouncePoint.get(1);
   * }
   * }
   * // BouncePoint bp = new BouncePoint(bounceX, bounceY, direction);
   * return bp;
   * error, still needs to change
   * return null;
   * }
   * // helper method to decide whether 2 lines are parallel
   * private boolean isParallel(double x1, double y1, double x2, double y2, double x3, double y3 , double x4, double y4) {
   * if(((x2-x1)/(y2-y1)) == ((x4-x3)/(y4-y3))) {
   * return true;
   * }else {
   * return false;
   * }
   * }
   * 
   * // helper method to find the intersection point x coordinate
   * private double getLinesIntersectionX(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4) {
   * double intersectionX;
   * if(isParallel(x1,y1,x2,y2,x3,y3,x4,y4)) {
   * return 0;
   * }
   * else {
   * intersectionX = ((y3-((y3-y4)/(x3-x4))*x3)-(y1-((y1-y2)/(x1-x2))*x1))/(((y1-y2)/(x1-x2))-((y3-y4)/(x3-x4)));
   * }
   * return intersectionX;
   * }
   * 
   * // helper method to find the intersection point y coordinate
   * private double getLinesIntersectionY(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4) {
   * double intersectionY;
   * if(isParallel(x1,y1,x2,y2,x3,y3,x4,y4)) {
   * return 0;
   * }
   * else {
   * intersectionY = ((y3-((y3-y4)/(x3-x4))*x3)-(y1-((y1-y2)/(x1-x2))*x1))/(((y1-y2)/(x1-x2))-((y3-y4)/(x3-x4)))*((y1-y2)/(x1-x2))+(y1-((y1-y2)/(x1-x2))*x1);
   * }
   * return intersectionY;
   * }
   * 
   * private boolean isOnLineSegment(double linesIntersectionX,double linesIntersectionY,double x1,double y1,double x2,double y2) {
   * if ((linesIntersectionX <= Math.max(x1,x2)) && (linesIntersectionX >= Math.min(x1,x2)) && (linesIntersectionY <= Math.max(y1,y2)) && (linesIntersectionY >= Math.min(y1,y2))) {
   * return true;
   * }
   * return false;
   * }
   * 
   * private double getLineSegmentIntersectionX(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4){
   * double xIntersection = 0;
   * if(isParallel(x1,y1,x2,y2,x3,y3,x4,y4)) {
   * return 0;  
   * }else {
   * double linesIntersectionX = getLinesIntersectionX(x1,y1,x2,y2,x3,y3,x4,y4);
   * double linesIntersectionY = getLinesIntersectionY(x1,y1,x2,y2,x3,y3,x4,y4);
   * if(isOnLineSegment(linesIntersectionX,linesIntersectionY,x1,y1,x2,y2)==false || isOnLineSegment(linesIntersectionX,linesIntersectionY,x3,y3,x4,y4)==false) {
   * return 0;
   * }else {
   * xIntersection = linesIntersectionX;
   * }
   * }
   * return xIntersection;
   * }
   * 
   * // helper method to get the line segment intersection point y coordinate 
   * private double getLineSegmentIntersectionY(double x1, double y1, double x2, double y2, double x3, double y3 , double x4, double y4) {
   * double yIntersection = 0;
   * if(isParallel(x1,y1,x2,y2,x3,y3,x4,y4)) {
   * return 0;  
   * }else {
   * double linesIntersectionX = getLinesIntersectionX(x1,y1,x2,y2,x3,y3,x4,y4);
   * double linesIntersectionY = getLinesIntersectionY(x1,y1,x2,y2,x3,y3,x4,y4);
   * if(isOnLineSegment(linesIntersectionX,linesIntersectionY,x1,y1,x2,y2)==false || isOnLineSegment(linesIntersectionX,linesIntersectionY,x3,y3,x4,y4)==false) {
   * return 0;
   * }else {
   * yIntersection = linesIntersectionY;
   * }
   * }
   * return yIntersection;
   * }
   * 
   * 
   * private double getDistanceFromPointToLine(double x, double y,double x1, double y1, double x2, double y2) {
   * double k = (y1-y2)/(x1-x2);
   * double b = y1-((y1-y2)/(x1-x2))*x1;
   * double d = (k*x-y+b)/(Math.sqrt(k*k+1));
   * return d;
   * }
   * 
   * // helper method get intersection of line and circle
   * private double getLineCircleIntersectionX(double x1, double y1, double x2, double y2, double x3, double y3 , double x4, double y4) {
   * double xIntersection =0;
   * if(x1 ==x2 && x1 ==x4 && x2 ==x4) {
   * return 0;
   * }
   * else if (y1 == y2 && y1 == y3 && y2 ==y3) {
   * return 0;
   * }
   * else if(getDistanceFromPointToLine(x4,y3,x1,x2,y1,y2) > 5) {
   * return 0;
   * }
   * else if(y1 == y2) {
   * double pointX_1 = x4 - Math.sqrt(Math.pow(5, 2)-Math.pow(Math.abs(y2-y3), 2));
   * double pointX_2 = x4 + Math.sqrt(Math.pow(5, 2)-Math.pow(Math.abs(y2-y3), 2));
   * if (Math.abs(x1-pointX_1)<Math.abs(x1-pointX_2)) {
   * xIntersection = pointX_1;
   * }
   * else {
   * xIntersection = pointX_2;
   * }
   * }
   * else if (x1 == x2) {
   * xIntersection =x1;
   * }
   * else if (getDistanceFromPointToLine(x4,y3,x1,x2,y1,y2) == 5) {
   * double k =(y2-y1)/(x2-x1);
   * double b = y2 - k*x2;
   * double A = Math.pow(k,2) +1;
   * double B = 2* (k*b-k*y3-x4);
   * xIntersection = -B/(2*A);
   * }
   * else if (getDistanceFromPointToLine(x4,y3,x1,x2,y1,y2) < 5){
   * double k =(y2-y1)/(x2-x1);
   * double b = y2 - k*x2;
   * double A = Math.pow(k,2) +1;
   * double B = 2* (k*b-k*y3-x4);
   * double C = Math.pow(y3,2)-Math.pow(5,2)+Math.pow(x4,2)-2*b*y3+Math.pow(b,2);
   * double point_1_X = (-B + Math.sqrt(Math.pow(B,2)-4*A*C))/(2*A);
   * double point_1_Y = k*point_1_X +b;
   * double point_2_X = (-B - Math.sqrt(Math.pow(B,2)-4*A*C))/(2*A);
   * double point_2_Y = k*point_2_X +b;
   * double l1 = Math.sqrt(Math.pow(Math.abs(x1-point_1_X),2)+Math.pow(Math.abs(y1-point_1_Y),2));
   * double l2 = Math.sqrt(Math.pow(Math.abs(x1-point_2_X),2)+Math.pow(Math.abs(y1-point_2_Y),2));
   * if(l1<l2){
   * xIntersection = point_1_X;
   * }
   * 
   * xIntersection = point_2_X;
   * }
   * }
   * return xIntersection;
   * }
   * 
   * // helper method get intersection of line and circle
   * private double getLineCircleIntersectionY(double x1, double y1, double x2, double y2, double x3, double y3 , double x4, double y4) {
   * double yIntersection =0;
   * if(x1 ==x2 && x1 ==x4 && x2 ==x4) {
   * return 0;
   * }
   * else if (y1 == y2 && y1 == y3 && y2 ==y3) {
   * return 0;
   * }
   * else if(getDistanceFromPointToLine(x4,y3,x1,x2,y1,y2) > 5) {
   * return 0;
   * }
   * else if(y1 == y2) {
   * yIntersection =y1;
   * }
   * else if (x1 == x2) {
   * double pointY_1 = y3 - Math.sqrt(Math.pow(5, 2)-Math.pow(Math.abs(x4-x1), 2));
   * double pointY_2 = y3 + Math.sqrt(Math.pow(5, 2)-Math.pow(Math.abs(x4-x1), 2));
   * if (Math.abs(y1-pointY_1)<Math.abs(y1-pointY_2)) {
   * yIntersection = pointY_1;
   * }
   * else {
   * yIntersection = pointY_2;
   * }
   * }
   * else if (getDistanceFromPointToLine(x4,y3,x1,x2,y1,y2) == 5) {
   * double k =(y2-y1)/(x2-x1);
   * double b = y2 - k*x2;
   * double A = Math.pow(k,2) +1;
   * double B = 2* (k*b-k*y3-x4);
   * yIntersection = k*(-B/(2*A))+b;
   * }
   * else if (getDistanceFromPointToLine(x4,y3,x1,x2,y1,y2) < 5){
   * double k =(y2-y1)/(x2-x1);
   * double b = y2 - k*x2;
   * double A = Math.pow(k,2) +1;
   * double B = 2* (k*b-k*y3-x4);
   * double C = Math.pow(y3,2)-Math.pow(5,2)+Math.pow(x4,2)-2*b*y3+Math.pow(b,2);
   * double point_1_X = (-B + Math.sqrt(Math.pow(B,2)-4*A*C))/(2*A);
   * double point_1_Y = k*point_1_X +b;
   * double point_2_X = (-B - Math.sqrt(Math.pow(B,2)-4*A*C))/(2*A);
   * double point_2_Y = k*point_2_X +b;
   * double l1 = Math.sqrt(Math.pow(Math.abs(x1-point_1_X),2)+Math.pow(Math.abs(y1-point_1_Y),2));
   * double l2 = Math.sqrt(Math.pow(Math.abs(x1-point_2_X),2)+Math.pow(Math.abs(y1-point_2_Y),2));
   * if(l1<l2){
   * yIntersection = point_1_Y;
   * }
   * 
   * yIntersection = point_2_Y;
   * }
   * }
   * return yIntersection;
   * }
   * 
   * private boolean isOnArc(double intersectionX,double intersectionY,double x3, double y3, double x4, double y4) {
   * if((intersectionX<=Math.max(x3, x4)) && (intersectionX >= Math.min(x3, x4)) && (intersectionY <= Math.max(y3, y4)) && (intersectionY >= Math.min(y3, y4))) {
   * return true;
   * }
   * return false;
   * }
   * 
   * private double getLineArcIntersectionX(double x1, double y1, double x2, double y2, double x3, double y3 , double x4, double y4) {
   * double xIntersection =0;
   * double circleIntersectionX = getLineCircleIntersectionX(x1,y1,x2,y2,x3,y3,x4,y4);
   * double circleIntersectionY = getLineCircleIntersectionY(x1,y1,x2,y2,x3,y3,x4,y4);
   * if (isOnLineSegment(circleIntersectionX,circleIntersectionY,x1,y1,x2,y2)==false || isOnArc(circleIntersectionX,circleIntersectionY,x3,y3,x4,y4)==false) {
   * return 0;
   * }
   * else {
   * xIntersection = circleIntersectionX;
   * }
   * return xIntersection;
   * }
   * 
   * private double getLineArcIntersectionY(double x1, double y1, double x2, double y2, double x3, double y3 , double x4, double y4) {
   * double yIntersection =0;
   * double circleIntersectionX = getLineCircleIntersectionX(x1,y1,x2,y2,x3,y3,x4,y4);
   * double circleIntersectionY = getLineCircleIntersectionY(x1,y1,x2,y2,x3,y3,x4,y4);
   * if (isOnLineSegment(circleIntersectionX,circleIntersectionY,x1,y1,x2,y2)==false || isOnArc(circleIntersectionX,circleIntersectionY,x3,y3,x4,y4)==false) {
   * return 0;
   * }
   * else {
   * yIntersection = circleIntersectionX;
   * }
   * return yIntersection;
   * }
   * 
   * private BouncePoint.BounceDirection getLineIntersectionBounceDirectionWall(double currentBallX, double currentBallY, double newBallX, double newBallY, double pointX1, double pointY1, double pointX2, double pointY2){
   * BouncePoint.BounceDirection direction = null;
   * if(((newBallX== Ball.BALL_DIAMETER/2) && (newBallY == Ball.BALL_DIAMETER/2)) || ((newBallX == Game.PLAY_AREA_SIDE-Ball.BALL_DIAMETER/2)&&(newBallY == Ball.BALL_DIAMETER/2))) {
   * direction = BouncePoint.BounceDirection.FLIP_BOTH;
   * }
   * else if(pointY1==pointY2) {
   * direction = BouncePoint.BounceDirection.FLIP_Y;
   * }
   * else if (pointX1==pointX2) {
   * direction = BouncePoint.BounceDirection.FLIP_X;
   * }
   * return direction;
   * }
   * 
   * private BouncePoint.BounceDirection getLineIntersectionBounceDirectionPaddle(double currentBallX, double currentBallY, double newBallX, double newBallY, double pointX1, double pointY1, double pointX2, double pointY2){
   * BouncePoint.BounceDirection direction = null;
   * if(pointY1==pointY2) {
   * direction = BouncePoint.BounceDirection.FLIP_Y;
   * }
   * else if (pointX1==pointX2) {
   * direction = BouncePoint.BounceDirection.FLIP_X;
   * }
   * return direction;
   * }
   * 
   * private BouncePoint.BounceDirection getArcIntersectionBounceDirectionPaddleLeft(double currentBallX, double currentBallY, double newBallX, double newBallY, double pointX1, double pointY1, double pointX2, double pointY2){
   * 
   * if(getBallDirectionX()>0 && getBallDirectionY()>0) {
   * return BouncePoint.BounceDirection.FLIP_X;
   * }
   * else if (getBallDirectionX()<0 && getBallDirectionY()>0) {
   * return BouncePoint.BounceDirection.FLIP_Y;
   * }
   * return null;
   * }
   * 
   * private BouncePoint.BounceDirection getArcIntersectionBounceDirectionPaddleRight(double currentBallX, double currentBallY, double newBallX, double newBallY, double pointX1, double pointY1, double pointX2, double pointY2){
   * 
   * if(getBallDirectionX()<0 && getBallDirectionY()>0) {
   * return BouncePoint.BounceDirection.FLIP_X;
   * }
   * else if (getBallDirectionX()>0 && getBallDirectionY()>0) {
   * return BouncePoint.BounceDirection.FLIP_Y;
   * }
   * return null;
   * }
   * 
   * private boolean isCloser(BouncePoint A, BouncePoint B){
   * //currentballX, currentballY
   * double aX = A.getX();
   * double aY = A.getY();
   * double bX = B.getX();
   * double bY = B.getY();
   * 
   * double disSquareA = (currentBallX - aX)*(currentBallX - aX) + (currentBallY-aY)*(currentBallY-aY);
   * double disSquareB = (currentBallX - bX)*(currentBallX - bX) + (currentBallY-bY)*(currentBallY-bY);
   * 
   * return disSquareA<disSquareB;
   * }
   */
  // line 863 "../../../../../Block223States.ump"
   public Point2D intersectionTester(Line2D line1, Line2D line2){
    return calculateIntersection(line1, line2);
  }

  // line 867 "../../../../../Block223States.ump"
   public Point2D intersectionTester(Line2D line, Arc2D arc){
    return calculateIntersection(line, arc);
  }

  // line 871 "../../../../../Block223States.ump"
   private Point2D calculateIntersection(Line2D line1, Line2D line2){
    // Point2D result = null;
    
    if (line1.intersectsLine(line2)) {

      double l1x1 = line1.getX1();
      double l1x2 = line1.getX2();
      double l1y1 = line1.getY1();
      double l1y2 = line1.getY2();

      double l2x1 = line2.getX1();
      double l2x2 = line2.getX2();
      double l2y1 = line2.getY1();
      double l2y2 = line2.getY2();

      double m1 = (l1y2 - l1y1) / (l1x2 - l1x1);
      double b1 = l1y1 - m1 * l1x1;
      double m2 = (l2y2 - l2y1) / (l2x2 - l2x1);
      double b2 = l2y1 - m2 * l2x1;

      if (Double.isInfinite(m1)) {
        return new Point2D.Double(l1x1, m2 * l1x1 + b2);
      }
      if (Double.isInfinite(m2)) {
        return new Point2D.Double(l2x1, m1 * l2x1 + b1);
      }

      double intx = (b2 - b1) / (m1 - m2);
      double inty = m1 * intx + b1;

      return new Point2D.Double(intx, inty);
    }
    return null;
  }

  // line 906 "../../../../../Block223States.ump"
   private Point2D calculateIntersection(Line2D line, Arc2D arc){
    // Point result = new Point();

    double xc = arc.getCenterX();
    double yc = arc.getCenterY();
    double rad = arc.getWidth() / 2;

    // System.out.println(String.format("xc: %f, yc: %f, rad: %f", xc, yc, rad));

    double x1 = line.getX1();
    double x2 = line.getX2();
    double y1 = line.getY1();
    double y2 = line.getY2();
    double a = y1 - y2;
    double b = x2 - x1;
    double c = x1 * y2 - x2 * y1;

    // System.out.println(String.format("x1: %f, y1: %f, x2: %f, y2: %f\na: %f, b: %f, c: %f", x1, y1, x2, y2, a, b, c));

    double rhs = (0 - c - a * xc - b * yc) / (rad * Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2)));
    double p = Math.atan(-b / a);

    double t1 = p + Math.acos(rhs);
    double t2 = p - Math.acos(rhs);

    if (t1 < 0) {
      t1 = t1 + 2 * Math.PI;
    }
    if (t2 < 0) {
      t2 = t2 + 2 * Math.PI;
    }

    double degt1 = Math.toDegrees(t1);
    double degt2 = Math.toDegrees(t2);
    // System.out.println(String.format("degt1: %f, degt2: %f", degt1, degt2));

    if (between(degt1, arc.getAngleStart(), arc.getAngleStart() + arc.getAngleExtent())) {
      
      double resX = rad * Math.cos(t1) + xc;
      double resY = -rad * Math.sin(t1) + yc;

      if (between(resX, line.getX1(), line.getX2()) && between(resY, line.getY1(), line.getY2())) {
        // System.out.println("Found intersection at " + degt1 + " degrees.");
        // result.setLocation(resX, resY);
        // return result;
        return new Point2D.Double(resX, resY);
      }
    }

    if (between(degt2, arc.getAngleStart(), arc.getAngleStart() + arc.getAngleExtent())) {
      double resX = rad * Math.cos(t2) + xc;
      double resY = -rad * Math.sin(t2) + yc;

      if (between(resX, line.getX1(), line.getX2()) && between(resY, line.getY1(), line.getY2())) {
        // System.out.println("Found intersection at " + degt2 + " degrees.");
        // result.setLocation(resX, resY);
        // return result;
        return new Point2D.Double(resX, resY);
      }
    }

    return null;
  }

  // line 970 "../../../../../Block223States.ump"
   private boolean between(double v, double x, double y){
    if (x > y) {
      return v >= y && v <= x;
    } else {
      return v >= x && v <= y;
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "id" + ":" + getId()+ "," +
            "score" + ":" + getScore()+ "," +
            "lives" + ":" + getLives()+ "," +
            "currentLevel" + ":" + getCurrentLevel()+ "," +
            "waitTime" + ":" + getWaitTime()+ "," +
            "playername" + ":" + getPlayername()+ "," +
            "ballDirectionX" + ":" + getBallDirectionX()+ "," +
            "ballDirectionY" + ":" + getBallDirectionY()+ "," +
            "currentBallX" + ":" + getCurrentBallX()+ "," +
            "currentBallY" + ":" + getCurrentBallY()+ "," +
            "currentPaddleLength" + ":" + getCurrentPaddleLength()+ "," +
            "currentPaddleX" + ":" + getCurrentPaddleX()+ "," +
            "currentPaddleY" + ":" + getCurrentPaddleY()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "player = "+(getPlayer()!=null?Integer.toHexString(System.identityHashCode(getPlayer())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "game = "+(getGame()!=null?Integer.toHexString(System.identityHashCode(getGame())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "bounce = "+(getBounce()!=null?Integer.toHexString(System.identityHashCode(getBounce())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "block223 = "+(getBlock223()!=null?Integer.toHexString(System.identityHashCode(getBlock223())):"null");
  }  
  //------------------------
  // DEVELOPER CODE - PROVIDED AS-IS
  //------------------------
  
  // line 110 "../../../../../Block223Persistence.ump"
  private static final long serialVersionUID = 8597675110221231714L ;

  
}