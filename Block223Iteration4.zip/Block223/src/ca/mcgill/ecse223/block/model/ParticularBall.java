/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4262.30c9ffc7c modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 49 "../../../../../Block223Player.ump"
public class ParticularBall
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //ParticularBall Attributes
  private double speedX;
  private double speedY;
  private double positionX;
  private double positionY;

  //ParticularBall Associations
  private Ball ball;
  private ParticularLevel particularLevel;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public ParticularBall(Ball aBall, ParticularLevel aParticularLevel)
  {
    speedX = aBall.getMinBallSpeedX();
    speedY = aBall.getMinBallSpeedY();
    positionX = 390 / 2;
    positionY = 390 / 4 * 3;
    if (!setBall(aBall))
    {
      throw new RuntimeException("Unable to create ParticularBall due to aBall");
    }
    if (aParticularLevel == null || aParticularLevel.getParticularBall() != null)
    {
      throw new RuntimeException("Unable to create ParticularBall due to aParticularLevel");
    }
    particularLevel = aParticularLevel;
  }

  public ParticularBall(Ball aBall, Level aLevelForParticularLevel, ParticularPaddle aParticularPaddleForParticularLevel, ParticularGame aParticularGameForParticularLevel)
  {
    speedX = aBall.getMinBallSpeedX();
    speedY = aBall.getMinBallSpeedY();
    positionX = 390 / 2;
    positionY = 390 / 4 * 3;
    boolean didAddBall = setBall(aBall);
    if (!didAddBall)
    {
      throw new RuntimeException("Unable to create particularBall due to ball");
    }
    particularLevel = new ParticularLevel(aLevelForParticularLevel, aParticularPaddleForParticularLevel, this, aParticularGameForParticularLevel);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setSpeedX(double aSpeedX)
  {
    boolean wasSet = false;
    speedX = aSpeedX;
    wasSet = true;
    return wasSet;
  }

  public boolean setSpeedY(double aSpeedY)
  {
    boolean wasSet = false;
    speedY = aSpeedY;
    wasSet = true;
    return wasSet;
  }

  public boolean setPositionX(double aPositionX)
  {
    boolean wasSet = false;
    positionX = aPositionX;
    wasSet = true;
    return wasSet;
  }

  public boolean setPositionY(double aPositionY)
  {
    boolean wasSet = false;
    positionY = aPositionY;
    wasSet = true;
    return wasSet;
  }

  public double getSpeedX()
  {
    return speedX;
  }

  public double getSpeedY()
  {
    return speedY;
  }

  public double getPositionX()
  {
    return positionX;
  }

  public double getPositionY()
  {
    return positionY;
  }
  /* Code from template association_GetOne */
  public Ball getBall()
  {
    return ball;
  }
  /* Code from template association_GetOne */
  public ParticularLevel getParticularLevel()
  {
    return particularLevel;
  }
  /* Code from template association_SetUnidirectionalOne */
  public boolean setBall(Ball aNewBall)
  {
    boolean wasSet = false;
    if (aNewBall != null)
    {
      ball = aNewBall;
      wasSet = true;
    }
    return wasSet;
  }

  public void delete()
  {
    ball = null;
    ParticularLevel existingParticularLevel = particularLevel;
    particularLevel = null;
    if (existingParticularLevel != null)
    {
      existingParticularLevel.delete();
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "speedX" + ":" + getSpeedX()+ "," +
            "speedY" + ":" + getSpeedY()+ "," +
            "positionX" + ":" + getPositionX()+ "," +
            "positionY" + ":" + getPositionY()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "ball = "+(getBall()!=null?Integer.toHexString(System.identityHashCode(getBall())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "particularLevel = "+(getParticularLevel()!=null?Integer.toHexString(System.identityHashCode(getParticularLevel())):"null");
  }
}