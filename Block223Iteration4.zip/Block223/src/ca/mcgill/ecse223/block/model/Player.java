/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4262.30c9ffc7c modeling language!*/

package ca.mcgill.ecse223.block.model;
import java.io.Serializable;
import java.util.*;

// line 41 "../../../../../Block223Persistence.ump"
// line 1 "../../../../../Block223Player.ump"
// line 49 "../../../../../Block223.ump"
public class Player extends UserRole implements Serializable
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Player Associations
  private List<ParticularGame> particularGames;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Player(String aPassword, Block223 aBlock223)
  {
    super(aPassword, aBlock223);
    particularGames = new ArrayList<ParticularGame>();
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetMany */
  public ParticularGame getParticularGame(int index)
  {
    ParticularGame aParticularGame = particularGames.get(index);
    return aParticularGame;
  }

  public List<ParticularGame> getParticularGames()
  {
    List<ParticularGame> newParticularGames = Collections.unmodifiableList(particularGames);
    return newParticularGames;
  }

  public int numberOfParticularGames()
  {
    int number = particularGames.size();
    return number;
  }

  public boolean hasParticularGames()
  {
    boolean has = particularGames.size() > 0;
    return has;
  }

  public int indexOfParticularGame(ParticularGame aParticularGame)
  {
    int index = particularGames.indexOf(aParticularGame);
    return index;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfParticularGames()
  {
    return 0;
  }
  /* Code from template association_AddManyToOptionalOne */
  public boolean addParticularGame(ParticularGame aParticularGame)
  {
    boolean wasAdded = false;
    if (particularGames.contains(aParticularGame)) { return false; }
    Player existingPlayer = aParticularGame.getPlayer();
    if (existingPlayer == null)
    {
      aParticularGame.setPlayer(this);
    }
    else if (!this.equals(existingPlayer))
    {
      existingPlayer.removeParticularGame(aParticularGame);
      addParticularGame(aParticularGame);
    }
    else
    {
      particularGames.add(aParticularGame);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeParticularGame(ParticularGame aParticularGame)
  {
    boolean wasRemoved = false;
    if (particularGames.contains(aParticularGame))
    {
      particularGames.remove(aParticularGame);
      aParticularGame.setPlayer(null);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addParticularGameAt(ParticularGame aParticularGame, int index)
  {  
    boolean wasAdded = false;
    if(addParticularGame(aParticularGame))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfParticularGames()) { index = numberOfParticularGames() - 1; }
      particularGames.remove(aParticularGame);
      particularGames.add(index, aParticularGame);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveParticularGameAt(ParticularGame aParticularGame, int index)
  {
    boolean wasAdded = false;
    if(particularGames.contains(aParticularGame))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfParticularGames()) { index = numberOfParticularGames() - 1; }
      particularGames.remove(aParticularGame);
      particularGames.add(index, aParticularGame);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addParticularGameAt(aParticularGame, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    while( !particularGames.isEmpty() )
    {
      particularGames.get(0).setPlayer(null);
    }
    super.delete();
  }
  
  //------------------------
  // DEVELOPER CODE - PROVIDED AS-IS
  //------------------------
  
  // line 44 "../../../../../Block223Persistence.ump"
  private static final long serialVersionUID = 1827937912988716L ;

  
}