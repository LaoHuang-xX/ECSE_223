/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4262.30c9ffc7c modeling language!*/

package ca.mcgill.ecse223.block.model;
import java.util.*;

// line 27 "../../../../../Block223Player.ump"
public class ParticularLevel
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //ParticularLevel Associations
  private List<ParticularBlockAssignment> particularBlockAssignments;
  private Level level;
  private ParticularPaddle particularPaddle;
  private ParticularBall particularBall;
  private ParticularGame particularGame;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public ParticularLevel(Level aLevel, ParticularPaddle aParticularPaddle, ParticularBall aParticularBall, ParticularGame aParticularGame)
  {
    particularBlockAssignments = new ArrayList<ParticularBlockAssignment>();
    if (!setLevel(aLevel))
    {
      throw new RuntimeException("Unable to create ParticularLevel due to aLevel");
    }
    if (aParticularPaddle == null || aParticularPaddle.getParticularLevel() != null)
    {
      throw new RuntimeException("Unable to create ParticularLevel due to aParticularPaddle");
    }
    particularPaddle = aParticularPaddle;
    if (aParticularBall == null || aParticularBall.getParticularLevel() != null)
    {
      throw new RuntimeException("Unable to create ParticularLevel due to aParticularBall");
    }
    particularBall = aParticularBall;
    boolean didAddParticularGame = setParticularGame(aParticularGame);
    if (!didAddParticularGame)
    {
      throw new RuntimeException("Unable to create particularLevel due to particularGame");
    }
  }

  public ParticularLevel(Level aLevel, Paddle aPaddleForParticularPaddle, Ball aBallForParticularBall, ParticularGame aParticularGame)
  {
    particularBlockAssignments = new ArrayList<ParticularBlockAssignment>();
    boolean didAddLevel = setLevel(aLevel);
    if (!didAddLevel)
    {
      throw new RuntimeException("Unable to create particularLevel due to level");
    }
    particularPaddle = new ParticularPaddle(aPaddleForParticularPaddle, this);
    particularBall = new ParticularBall(aBallForParticularBall, this);
    boolean didAddParticularGame = setParticularGame(aParticularGame);
    if (!didAddParticularGame)
    {
      throw new RuntimeException("Unable to create particularLevel due to particularGame");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetMany */
  public ParticularBlockAssignment getParticularBlockAssignment(int index)
  {
    ParticularBlockAssignment aParticularBlockAssignment = particularBlockAssignments.get(index);
    return aParticularBlockAssignment;
  }

  public List<ParticularBlockAssignment> getParticularBlockAssignments()
  {
    List<ParticularBlockAssignment> newParticularBlockAssignments = Collections.unmodifiableList(particularBlockAssignments);
    return newParticularBlockAssignments;
  }

  public int numberOfParticularBlockAssignments()
  {
    int number = particularBlockAssignments.size();
    return number;
  }

  public boolean hasParticularBlockAssignments()
  {
    boolean has = particularBlockAssignments.size() > 0;
    return has;
  }

  public int indexOfParticularBlockAssignment(ParticularBlockAssignment aParticularBlockAssignment)
  {
    int index = particularBlockAssignments.indexOf(aParticularBlockAssignment);
    return index;
  }
  /* Code from template association_GetOne */
  public Level getLevel()
  {
    return level;
  }
  /* Code from template association_GetOne */
  public ParticularPaddle getParticularPaddle()
  {
    return particularPaddle;
  }
  /* Code from template association_GetOne */
  public ParticularBall getParticularBall()
  {
    return particularBall;
  }
  /* Code from template association_GetOne */
  public ParticularGame getParticularGame()
  {
    return particularGame;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfParticularBlockAssignments()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public ParticularBlockAssignment addParticularBlockAssignment(int aGridHorizontalPosition, int aGridVerticalPosition, Block aBlock)
  {
    return new ParticularBlockAssignment(aGridHorizontalPosition, aGridVerticalPosition, aBlock, this);
  }

  public boolean addParticularBlockAssignment(ParticularBlockAssignment aParticularBlockAssignment)
  {
    boolean wasAdded = false;
    if (particularBlockAssignments.contains(aParticularBlockAssignment)) { return false; }
    ParticularLevel existingParticularLevel = aParticularBlockAssignment.getParticularLevel();
    boolean isNewParticularLevel = existingParticularLevel != null && !this.equals(existingParticularLevel);
    if (isNewParticularLevel)
    {
      aParticularBlockAssignment.setParticularLevel(this);
    }
    else
    {
      particularBlockAssignments.add(aParticularBlockAssignment);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeParticularBlockAssignment(ParticularBlockAssignment aParticularBlockAssignment)
  {
    boolean wasRemoved = false;
    //Unable to remove aParticularBlockAssignment, as it must always have a particularLevel
    if (!this.equals(aParticularBlockAssignment.getParticularLevel()))
    {
      particularBlockAssignments.remove(aParticularBlockAssignment);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addParticularBlockAssignmentAt(ParticularBlockAssignment aParticularBlockAssignment, int index)
  {  
    boolean wasAdded = false;
    if(addParticularBlockAssignment(aParticularBlockAssignment))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfParticularBlockAssignments()) { index = numberOfParticularBlockAssignments() - 1; }
      particularBlockAssignments.remove(aParticularBlockAssignment);
      particularBlockAssignments.add(index, aParticularBlockAssignment);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveParticularBlockAssignmentAt(ParticularBlockAssignment aParticularBlockAssignment, int index)
  {
    boolean wasAdded = false;
    if(particularBlockAssignments.contains(aParticularBlockAssignment))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfParticularBlockAssignments()) { index = numberOfParticularBlockAssignments() - 1; }
      particularBlockAssignments.remove(aParticularBlockAssignment);
      particularBlockAssignments.add(index, aParticularBlockAssignment);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addParticularBlockAssignmentAt(aParticularBlockAssignment, index);
    }
    return wasAdded;
  }
  /* Code from template association_SetUnidirectionalOne */
  public boolean setLevel(Level aNewLevel)
  {
    boolean wasSet = false;
    if (aNewLevel != null)
    {
      level = aNewLevel;
      wasSet = true;
    }
    return wasSet;
  }
  /* Code from template association_SetOneToAtMostN */
  public boolean setParticularGame(ParticularGame aParticularGame)
  {
    boolean wasSet = false;
    //Must provide particularGame to particularLevel
    if (aParticularGame == null)
    {
      return wasSet;
    }

    //particularGame already at maximum (99)
    if (aParticularGame.numberOfParticularLevels() >= ParticularGame.maximumNumberOfParticularLevels())
    {
      return wasSet;
    }
    
    ParticularGame existingParticularGame = particularGame;
    particularGame = aParticularGame;
    if (existingParticularGame != null && !existingParticularGame.equals(aParticularGame))
    {
      boolean didRemove = existingParticularGame.removeParticularLevel(this);
      if (!didRemove)
      {
        particularGame = existingParticularGame;
        return wasSet;
      }
    }
    particularGame.addParticularLevel(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    while (particularBlockAssignments.size() > 0)
    {
      ParticularBlockAssignment aParticularBlockAssignment = particularBlockAssignments.get(particularBlockAssignments.size() - 1);
      aParticularBlockAssignment.delete();
      particularBlockAssignments.remove(aParticularBlockAssignment);
    }
    
    level = null;
    ParticularPaddle existingParticularPaddle = particularPaddle;
    particularPaddle = null;
    if (existingParticularPaddle != null)
    {
      existingParticularPaddle.delete();
    }
    ParticularBall existingParticularBall = particularBall;
    particularBall = null;
    if (existingParticularBall != null)
    {
      existingParticularBall.delete();
    }
    ParticularGame placeholderParticularGame = particularGame;
    this.particularGame = null;
    if(placeholderParticularGame != null)
    {
      placeholderParticularGame.removeParticularLevel(this);
    }
  }

}