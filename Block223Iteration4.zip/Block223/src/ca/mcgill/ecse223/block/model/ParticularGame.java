/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4262.30c9ffc7c modeling language!*/

package ca.mcgill.ecse223.block.model;
import java.util.*;

// line 16 "../../../../../Block223Player.ump"
// line 1 "../../../../../Block223States.ump"
public class ParticularGame
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static int nextId = 1;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //ParticularGame Attributes
  private boolean testMode;
  private int currentLevel;
  private int score;
  private int numberOfLives;

  //Autounique Attributes
  private int id;

  //ParticularGame State Machines
  public enum GameState { Start, Paused, Playing, GameOver }
  private GameState gameState;

  //ParticularGame Associations
  private Game game;
  private List<ParticularLevel> particularLevels;
  private Player player;
  private Block223 block223;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public ParticularGame(boolean aTestMode, Game aGame, Block223 aBlock223)
  {
    testMode = aTestMode;
    currentLevel = 1;
    score = 0;
    numberOfLives = 3;
    id = nextId++;
    if (!setGame(aGame))
    {
      throw new RuntimeException("Unable to create ParticularGame due to aGame");
    }
    particularLevels = new ArrayList<ParticularLevel>();
    boolean didAddBlock223 = setBlock223(aBlock223);
    if (!didAddBlock223)
    {
      throw new RuntimeException("Unable to create particularGame due to block223");
    }
    setGameState(GameState.Start);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setTestMode(boolean aTestMode)
  {
    boolean wasSet = false;
    testMode = aTestMode;
    wasSet = true;
    return wasSet;
  }

  public boolean setCurrentLevel(int aCurrentLevel)
  {
    boolean wasSet = false;
    currentLevel = aCurrentLevel;
    wasSet = true;
    return wasSet;
  }

  public boolean setScore(int aScore)
  {
    boolean wasSet = false;
    score = aScore;
    wasSet = true;
    return wasSet;
  }

  public boolean setNumberOfLives(int aNumberOfLives)
  {
    boolean wasSet = false;
    numberOfLives = aNumberOfLives;
    wasSet = true;
    return wasSet;
  }

  public boolean getTestMode()
  {
    return testMode;
  }

  public int getCurrentLevel()
  {
    return currentLevel;
  }

  public int getScore()
  {
    return score;
  }

  public int getNumberOfLives()
  {
    return numberOfLives;
  }

  public int getId()
  {
    return id;
  }
  /* Code from template attribute_IsBoolean */
  public boolean isTestMode()
  {
    return testMode;
  }

  public String getGameStateFullName()
  {
    String answer = gameState.toString();
    return answer;
  }

  public GameState getGameState()
  {
    return gameState;
  }

  public boolean initialize()
  {
    boolean wasEventProcessed = false;
    
    GameState aGameState = gameState;
    switch (aGameState)
    {
      case Start:
        // line 4 "../../../../../Block223States.ump"
        initializeGame();
        setGameState(GameState.Paused);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean togglePause()
  {
    boolean wasEventProcessed = false;
    
    GameState aGameState = gameState;
    switch (aGameState)
    {
      case Paused:
        setGameState(GameState.Playing);
        wasEventProcessed = true;
        break;
      case Playing:
        setGameState(GameState.Paused);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean moveBall()
  {
    boolean wasEventProcessed = false;
    
    GameState aGameState = gameState;
    switch (aGameState)
    {
      case Playing:
        if (ballHittingBlock())
        {
        // line 26 "../../../../../Block223States.ump"
          updateBallBlock();
          setGameState(GameState.Playing);
          wasEventProcessed = true;
          break;
        }
        if (ballHittingWall())
        {
        // line 29 "../../../../../Block223States.ump"
          updateBallWall();
          setGameState(GameState.Playing);
          wasEventProcessed = true;
          break;
        }
        if (ballHittingPaddle())
        {
        // line 32 "../../../../../Block223States.ump"
          updateBallPaddle();
          setGameState(GameState.Playing);
          wasEventProcessed = true;
          break;
        }
        if (ballOutOfBounds()&&getNumberOfLives()>1)
        {
        // line 35 "../../../../../Block223States.ump"
          numberOfLives--;
                resetBallPosition();
          setGameState(GameState.Paused);
          wasEventProcessed = true;
          break;
        }
        if (ballOutOfBounds()&&getNumberOfLives()==1)
        {
        // line 39 "../../../../../Block223States.ump"
          numberOfLives--;
          setGameState(GameState.GameOver);
          wasEventProcessed = true;
          break;
        }
        // line 42 "../../../../../Block223States.ump"
        updateBall();
        setGameState(GameState.Playing);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean levelFinished()
  {
    boolean wasEventProcessed = false;
    
    GameState aGameState = gameState;
    switch (aGameState)
    {
      case Playing:
        if (getCurrentLevel()<getGame().getLevels().size())
        {
        // line 46 "../../../../../Block223States.ump"
          currentLevel++;
          setGameState(GameState.Paused);
          wasEventProcessed = true;
          break;
        }
        if (getCurrentLevel()==getGame().getLevels().size())
        {
          setGameState(GameState.GameOver);
          wasEventProcessed = true;
          break;
        }
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private void setGameState(GameState aGameState)
  {
    gameState = aGameState;

    // entry actions and do activities
    switch(gameState)
    {
      case GameOver:
        // line 52 "../../../../../Block223States.ump"
        cleanUp();
        delete();
        break;
    }
  }
  /* Code from template association_GetOne */
  public Game getGame()
  {
    return game;
  }
  /* Code from template association_GetMany */
  public ParticularLevel getParticularLevel(int index)
  {
    ParticularLevel aParticularLevel = particularLevels.get(index);
    return aParticularLevel;
  }

  public List<ParticularLevel> getParticularLevels()
  {
    List<ParticularLevel> newParticularLevels = Collections.unmodifiableList(particularLevels);
    return newParticularLevels;
  }

  public int numberOfParticularLevels()
  {
    int number = particularLevels.size();
    return number;
  }

  public boolean hasParticularLevels()
  {
    boolean has = particularLevels.size() > 0;
    return has;
  }

  public int indexOfParticularLevel(ParticularLevel aParticularLevel)
  {
    int index = particularLevels.indexOf(aParticularLevel);
    return index;
  }
  /* Code from template association_GetOne */
  public Player getPlayer()
  {
    return player;
  }

  public boolean hasPlayer()
  {
    boolean has = player != null;
    return has;
  }
  /* Code from template association_GetOne */
  public Block223 getBlock223()
  {
    return block223;
  }
  /* Code from template association_SetUnidirectionalOne */
  public boolean setGame(Game aNewGame)
  {
    boolean wasSet = false;
    if (aNewGame != null)
    {
      game = aNewGame;
      wasSet = true;
    }
    return wasSet;
  }
  /* Code from template association_IsNumberOfValidMethod */
  public boolean isNumberOfParticularLevelsValid()
  {
    boolean isValid = numberOfParticularLevels() >= minimumNumberOfParticularLevels() && numberOfParticularLevels() <= maximumNumberOfParticularLevels();
    return isValid;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfParticularLevels()
  {
    return 1;
  }
  /* Code from template association_MaximumNumberOfMethod */
  public static int maximumNumberOfParticularLevels()
  {
    return 99;
  }
  /* Code from template association_AddMNToOnlyOne */
  public ParticularLevel addParticularLevel(Level aLevel, ParticularPaddle aParticularPaddle, ParticularBall aParticularBall)
  {
    if (numberOfParticularLevels() >= maximumNumberOfParticularLevels())
    {
      return null;
    }
    else
    {
      return new ParticularLevel(aLevel, aParticularPaddle, aParticularBall, this);
    }
  }

  public boolean addParticularLevel(ParticularLevel aParticularLevel)
  {
    boolean wasAdded = false;
    if (particularLevels.contains(aParticularLevel)) { return false; }
    if (numberOfParticularLevels() >= maximumNumberOfParticularLevels())
    {
      return wasAdded;
    }

    ParticularGame existingParticularGame = aParticularLevel.getParticularGame();
    boolean isNewParticularGame = existingParticularGame != null && !this.equals(existingParticularGame);

    if (isNewParticularGame && existingParticularGame.numberOfParticularLevels() <= minimumNumberOfParticularLevels())
    {
      return wasAdded;
    }

    if (isNewParticularGame)
    {
      aParticularLevel.setParticularGame(this);
    }
    else
    {
      particularLevels.add(aParticularLevel);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeParticularLevel(ParticularLevel aParticularLevel)
  {
    boolean wasRemoved = false;
    //Unable to remove aParticularLevel, as it must always have a particularGame
    if (this.equals(aParticularLevel.getParticularGame()))
    {
      return wasRemoved;
    }

    //particularGame already at minimum (1)
    if (numberOfParticularLevels() <= minimumNumberOfParticularLevels())
    {
      return wasRemoved;
    }
    particularLevels.remove(aParticularLevel);
    wasRemoved = true;
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addParticularLevelAt(ParticularLevel aParticularLevel, int index)
  {  
    boolean wasAdded = false;
    if(addParticularLevel(aParticularLevel))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfParticularLevels()) { index = numberOfParticularLevels() - 1; }
      particularLevels.remove(aParticularLevel);
      particularLevels.add(index, aParticularLevel);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveParticularLevelAt(ParticularLevel aParticularLevel, int index)
  {
    boolean wasAdded = false;
    if(particularLevels.contains(aParticularLevel))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfParticularLevels()) { index = numberOfParticularLevels() - 1; }
      particularLevels.remove(aParticularLevel);
      particularLevels.add(index, aParticularLevel);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addParticularLevelAt(aParticularLevel, index);
    }
    return wasAdded;
  }
  /* Code from template association_SetOptionalOneToMany */
  public boolean setPlayer(Player aPlayer)
  {
    boolean wasSet = false;
    Player existingPlayer = player;
    player = aPlayer;
    if (existingPlayer != null && !existingPlayer.equals(aPlayer))
    {
      existingPlayer.removeParticularGame(this);
    }
    if (aPlayer != null)
    {
      aPlayer.addParticularGame(this);
    }
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_SetOneToMany */
  public boolean setBlock223(Block223 aBlock223)
  {
    boolean wasSet = false;
    if (aBlock223 == null)
    {
      return wasSet;
    }

    Block223 existingBlock223 = block223;
    block223 = aBlock223;
    if (existingBlock223 != null && !existingBlock223.equals(aBlock223))
    {
      existingBlock223.removeParticularGame(this);
    }
    block223.addParticularGame(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    game = null;
    while (particularLevels.size() > 0)
    {
      ParticularLevel aParticularLevel = particularLevels.get(particularLevels.size() - 1);
      aParticularLevel.delete();
      particularLevels.remove(aParticularLevel);
    }
    
    if (player != null)
    {
      Player placeholderPlayer = player;
      this.player = null;
      placeholderPlayer.removeParticularGame(this);
    }
    Block223 placeholderBlock223 = block223;
    this.block223 = null;
    if(placeholderBlock223 != null)
    {
      placeholderBlock223.removeParticularGame(this);
    }
  }

  // line 59 "../../../../../Block223States.ump"
   private boolean ballHittingNothing(){
    return false;
  }

  // line 63 "../../../../../Block223States.ump"
   private boolean ballOutOfBounds(){
    return false;
  }

  // line 67 "../../../../../Block223States.ump"
   private boolean ballHittingWall(){
    return false;
  }

  // line 71 "../../../../../Block223States.ump"
   private boolean ballHittingPaddle(){
    return false;
  }

  // line 75 "../../../../../Block223States.ump"
   private boolean ballHittingBlock(){
    return false;
  }

  // line 80 "../../../../../Block223States.ump"
   private void resetBallPosition(){
    
  }

  // line 84 "../../../../../Block223States.ump"
   private void updateScore(Block block){
    
  }

  // line 88 "../../../../../Block223States.ump"
   private void updateBall(){
    
  }

  // line 92 "../../../../../Block223States.ump"
   private void updateBallWall(){
    
  }

  // line 96 "../../../../../Block223States.ump"
   private void updateBallPaddle(){
    
  }

  // line 100 "../../../../../Block223States.ump"
   private void updateBallBlock(){
    
  }

  // line 104 "../../../../../Block223States.ump"
   private void initializeGame(){
    
  }

  // line 108 "../../../../../Block223States.ump"
   private void updateBallPosition(){
    
  }

  // line 112 "../../../../../Block223States.ump"
   private void updateBallSpeed(){
    
  }

  // line 116 "../../../../../Block223States.ump"
   private void updateHallOfFame(){
    
  }

  // line 119 "../../../../../Block223States.ump"
   private void cleanUp(){
    if (!testMode) {
            updateHallOfFame();
        }
        this.delete();
  }


  public String toString()
  {
    return super.toString() + "["+
            "id" + ":" + getId()+ "," +
            "testMode" + ":" + getTestMode()+ "," +
            "currentLevel" + ":" + getCurrentLevel()+ "," +
            "score" + ":" + getScore()+ "," +
            "numberOfLives" + ":" + getNumberOfLives()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "game = "+(getGame()!=null?Integer.toHexString(System.identityHashCode(getGame())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "player = "+(getPlayer()!=null?Integer.toHexString(System.identityHashCode(getPlayer())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "block223 = "+(getBlock223()!=null?Integer.toHexString(System.identityHashCode(getBlock223())):"null");
  }
}