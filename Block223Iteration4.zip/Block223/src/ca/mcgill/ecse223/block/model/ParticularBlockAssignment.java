/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4262.30c9ffc7c modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 35 "../../../../../Block223Player.ump"
public class ParticularBlockAssignment
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //ParticularBlockAssignment Attributes
  private int gridHorizontalPosition;
  private int gridVerticalPosition;

  //ParticularBlockAssignment Associations
  private Block block;
  private ParticularLevel particularLevel;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public ParticularBlockAssignment(int aGridHorizontalPosition, int aGridVerticalPosition, Block aBlock, ParticularLevel aParticularLevel)
  {
    gridHorizontalPosition = aGridHorizontalPosition;
    gridVerticalPosition = aGridVerticalPosition;
    if (!setBlock(aBlock))
    {
      throw new RuntimeException("Unable to create ParticularBlockAssignment due to aBlock");
    }
    boolean didAddParticularLevel = setParticularLevel(aParticularLevel);
    if (!didAddParticularLevel)
    {
      throw new RuntimeException("Unable to create particularBlockAssignment due to particularLevel");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setGridHorizontalPosition(int aGridHorizontalPosition)
  {
    boolean wasSet = false;
    gridHorizontalPosition = aGridHorizontalPosition;
    wasSet = true;
    return wasSet;
  }

  public boolean setGridVerticalPosition(int aGridVerticalPosition)
  {
    boolean wasSet = false;
    gridVerticalPosition = aGridVerticalPosition;
    wasSet = true;
    return wasSet;
  }

  public int getGridHorizontalPosition()
  {
    return gridHorizontalPosition;
  }

  public int getGridVerticalPosition()
  {
    return gridVerticalPosition;
  }
  /* Code from template association_GetOne */
  public Block getBlock()
  {
    return block;
  }
  /* Code from template association_GetOne */
  public ParticularLevel getParticularLevel()
  {
    return particularLevel;
  }
  /* Code from template association_SetUnidirectionalOne */
  public boolean setBlock(Block aNewBlock)
  {
    boolean wasSet = false;
    if (aNewBlock != null)
    {
      block = aNewBlock;
      wasSet = true;
    }
    return wasSet;
  }
  /* Code from template association_SetOneToMany */
  public boolean setParticularLevel(ParticularLevel aParticularLevel)
  {
    boolean wasSet = false;
    if (aParticularLevel == null)
    {
      return wasSet;
    }

    ParticularLevel existingParticularLevel = particularLevel;
    particularLevel = aParticularLevel;
    if (existingParticularLevel != null && !existingParticularLevel.equals(aParticularLevel))
    {
      existingParticularLevel.removeParticularBlockAssignment(this);
    }
    particularLevel.addParticularBlockAssignment(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    block = null;
    ParticularLevel placeholderParticularLevel = particularLevel;
    this.particularLevel = null;
    if(placeholderParticularLevel != null)
    {
      placeholderParticularLevel.removeParticularBlockAssignment(this);
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "gridHorizontalPosition" + ":" + getGridHorizontalPosition()+ "," +
            "gridVerticalPosition" + ":" + getGridVerticalPosition()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "block = "+(getBlock()!=null?Integer.toHexString(System.identityHashCode(getBlock())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "particularLevel = "+(getParticularLevel()!=null?Integer.toHexString(System.identityHashCode(getParticularLevel())):"null");
  }
}