/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4262.30c9ffc7c modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 42 "../../../../../Block223Player.ump"
public class ParticularPaddle
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //ParticularPaddle Attributes
  private int length;
  private double position;

  //ParticularPaddle Associations
  private Paddle paddle;
  private ParticularLevel particularLevel;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public ParticularPaddle(Paddle aPaddle, ParticularLevel aParticularLevel)
  {
    length = aPaddle.getMaxPaddleLength();
    position = 390 / 2;
    if (!setPaddle(aPaddle))
    {
      throw new RuntimeException("Unable to create ParticularPaddle due to aPaddle");
    }
    if (aParticularLevel == null || aParticularLevel.getParticularPaddle() != null)
    {
      throw new RuntimeException("Unable to create ParticularPaddle due to aParticularLevel");
    }
    particularLevel = aParticularLevel;
  }

  public ParticularPaddle(Paddle aPaddle, Level aLevelForParticularLevel, ParticularBall aParticularBallForParticularLevel, ParticularGame aParticularGameForParticularLevel)
  {
    length = aPaddle.getMaxPaddleLength();
    position = 390 / 2;
    boolean didAddPaddle = setPaddle(aPaddle);
    if (!didAddPaddle)
    {
      throw new RuntimeException("Unable to create particularPaddle due to paddle");
    }
    particularLevel = new ParticularLevel(aLevelForParticularLevel, this, aParticularBallForParticularLevel, aParticularGameForParticularLevel);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setLength(int aLength)
  {
    boolean wasSet = false;
    length = aLength;
    wasSet = true;
    return wasSet;
  }

  public boolean setPosition(double aPosition)
  {
    boolean wasSet = false;
    position = aPosition;
    wasSet = true;
    return wasSet;
  }

  public int getLength()
  {
    return length;
  }

  public double getPosition()
  {
    return position;
  }
  /* Code from template association_GetOne */
  public Paddle getPaddle()
  {
    return paddle;
  }
  /* Code from template association_GetOne */
  public ParticularLevel getParticularLevel()
  {
    return particularLevel;
  }
  /* Code from template association_SetUnidirectionalOne */
  public boolean setPaddle(Paddle aNewPaddle)
  {
    boolean wasSet = false;
    if (aNewPaddle != null)
    {
      paddle = aNewPaddle;
      wasSet = true;
    }
    return wasSet;
  }

  public void delete()
  {
    paddle = null;
    ParticularLevel existingParticularLevel = particularLevel;
    particularLevel = null;
    if (existingParticularLevel != null)
    {
      existingParticularLevel.delete();
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "length" + ":" + getLength()+ "," +
            "position" + ":" + getPosition()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "paddle = "+(getPaddle()!=null?Integer.toHexString(System.identityHashCode(getPaddle())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "particularLevel = "+(getParticularLevel()!=null?Integer.toHexString(System.identityHashCode(getParticularLevel())):"null");
  }
}