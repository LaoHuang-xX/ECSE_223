/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4262.30c9ffc7c modeling language!*/

package ca.mcgill.ecse223.block.controller;

// line 14 "../../../../../Block223TransferObjects.ump"
public class TOParticularGame
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //TOParticularGame Attributes
  private int id;
  private int currentLevel;
  private int score;
  private int numberOfLives;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public TOParticularGame(int aId, int aCurrentLevel, int aScore, int aNumberOfLives)
  {
    id = aId;
    currentLevel = aCurrentLevel;
    score = aScore;
    numberOfLives = aNumberOfLives;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setId(int aId)
  {
    boolean wasSet = false;
    id = aId;
    wasSet = true;
    return wasSet;
  }

  public boolean setCurrentLevel(int aCurrentLevel)
  {
    boolean wasSet = false;
    currentLevel = aCurrentLevel;
    wasSet = true;
    return wasSet;
  }

  public boolean setScore(int aScore)
  {
    boolean wasSet = false;
    score = aScore;
    wasSet = true;
    return wasSet;
  }

  public boolean setNumberOfLives(int aNumberOfLives)
  {
    boolean wasSet = false;
    numberOfLives = aNumberOfLives;
    wasSet = true;
    return wasSet;
  }

  public int getId()
  {
    return id;
  }

  public int getCurrentLevel()
  {
    return currentLevel;
  }

  public int getScore()
  {
    return score;
  }

  public int getNumberOfLives()
  {
    return numberOfLives;
  }

  public void delete()
  {}


  public String toString()
  {
    return super.toString() + "["+
            "id" + ":" + getId()+ "," +
            "currentLevel" + ":" + getCurrentLevel()+ "," +
            "score" + ":" + getScore()+ "," +
            "numberOfLives" + ":" + getNumberOfLives()+ "]";
  }
}