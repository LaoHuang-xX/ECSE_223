package ca.mcgill.ecse223.block.controller;

import java.util.ArrayList;
import java.util.List;

import ca.mcgill.ecse223.block.application.Block223Application;
import ca.mcgill.ecse223.block.controller.TOUserMode.Mode;
import ca.mcgill.ecse223.block.model.*;
import ca.mcgill.ecse223.block.persistence.Block223Persistence;

public class Block223Controller {

	// ****************************
	// Modifier methods
	// ****************************
	public static void createGame(String name) throws InvalidInputException {
		Block223 block223 = Block223Application.getBlock223();
		UserRole user = Block223Application.getCurrentUserRole();
		Admin admin;
		if (user instanceof Admin) {
			admin = (Admin) user;
			try {
				if (Block223Application.getBlock223().findGame(name) != null) {
					throw new InvalidInputException("The name of a game must be unique.");
				}
				new Game(false, name, 1, admin, 1, 1, 1, 10, 10, block223);
			} catch (RuntimeException e) {
				throw new InvalidInputException(e.getMessage());
			}
		} else {
			throw new InvalidInputException("Admin privileges are required to create a game.");
		}
	}

	public static void setGameDetails(int nrLevels, int nrBlocksPerLevel, int minBallSpeedX, int minBallSpeedY,
			Double ballSpeedIncreaseFactor, int maxPaddleLength, int minPaddleLength) throws InvalidInputException {
		UserRole currentUser = Block223Application.getCurrentUserRole();
		if (!(currentUser instanceof Admin)) {
			throw new InvalidInputException("Admin privileges are required to define game settings.");
		}

		Game currentGame = Block223Application.getCurrentGame();
		if (currentGame == null) {
			throw new InvalidInputException("A game must be selected to define game settings.");
		}

		if (Block223Application.getCurrentGame().getAdmin() != currentUser) {
			throw new InvalidInputException("Only the admin who created the game can define its game settings.");
		}

		if ((nrLevels < 1) || (nrLevels > 99)) {
			throw new InvalidInputException("The number of levels must be between 1 and 99");
		}

		try {
			currentGame.setNrBlocksPerLevel(nrBlocksPerLevel);
			Ball ball = currentGame.getBall();
			ball.setMinBallSpeedX(minBallSpeedX);
			ball.setMinBallSpeedY(minBallSpeedY);
			ball.setBallSpeedIncreaseFactor(ballSpeedIncreaseFactor);
			Paddle paddle = currentGame.getPaddle();
			paddle.setMaxPaddleLength(maxPaddleLength);
			paddle.setMinPaddleLength(minPaddleLength);

			List<Level> levels = currentGame.getLevels();
			int size = levels.size();

			// add levels to right number
			while (nrLevels > size) {
				currentGame.addLevel();
				size = levels.size();
			}

			// removes levels to the right number
			while (nrLevels < size) {
				Level level = currentGame.getLevel(size - 1);
				level.delete();
				size = levels.size();
			}
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}
	}

	public static void addLevelToGame() throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;

		if (!(role instanceof Admin)) {
			throw new InvalidInputException("Admin privileges are required to add level.");
		} else {
			admin = (Admin) role;
		}

		Game game = Block223Application.getCurrentGame();

		if (game == null) {
			throw new InvalidInputException("A game must be selected to add level to it.");
		}

		if (admin != game.getAdmin()) {
			throw new InvalidInputException("Only the admin who created the game can add a level.");
		}

		try {
			game.addLevel();
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}
	}

	public static void deleteGame(String name) throws InvalidInputException {
		Game game = Block223Application.getBlock223().findGame(name);

		// Checking if the current user is an admin
		if (!(Block223Application.getCurrentUserRole() instanceof Admin)) {
			throw new InvalidInputException("Admin privileges are required to delete a game.");
		}

		// Checking if the current user is the owner of the game
		if (Block223Application.getCurrentUserRole() != Block223Application.getCurrentGame().getAdmin()) {
			throw new InvalidInputException("Only the admin who created the game can delete the game.");
		}
		if (game != null) {
			game.delete();
		}

		// Saving the file into the data file
		try {
			Block223Persistence.save(Block223Application.getBlock223());
		} catch (RuntimeException e) {

			// If there is an error when saving
			throw new InvalidInputException(e.getMessage());
		}
	}

	public static void selectGame(String name) throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to select a game.");
		}
		Game game = Block223Application.getBlock223().findGame(name);

		if (game == null) {
			throw new InvalidInputException("A game with name " + name + " does not exist.");
		}
		if (game.getAdmin() != admin) {
			throw new InvalidInputException("Only the admin who created the game can select the game.");
		}

		Block223Application.setCurrentGame(game);
	}

	public static void updateGame(String name, int nrLevels, int nrBlocksPerLevel, int minBallSpeedX, int minBallSpeedY,
			Double ballSpeedIncreaseFactor, int maxPaddleLength, int minPaddleLength) throws InvalidInputException {

		// If the user is an admin
		if (!(Block223Application.getCurrentUserRole() instanceof Admin)) {
			throw new InvalidInputException("Admin privileges are required to define game settings.");
		}

		// If a game isn't selected
		if (Block223Application.getCurrentGame() == null) {
			throw new InvalidInputException("A game must be selected to define game settings.");
		}

		// If the user is not the owner of the game
		if (Block223Application.getCurrentUserRole() != Block223Application.getCurrentGame().getAdmin()) {
			throw new InvalidInputException("Only the admin who created the game can update the game.");
		}

		Game game = Block223Application.getCurrentGame();
		String currentName = game.getName();
		try {
			if (currentName != name) {
				game.setName(name);

			}
			Block223Controller.setGameDetails(nrLevels, nrBlocksPerLevel, minBallSpeedX, minBallSpeedY,
					ballSpeedIncreaseFactor, maxPaddleLength, minPaddleLength);
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}
	}

	public static void addBlock(int red, int green, int blue, int points) throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to add a block.");
		}
		Game game = Block223Application.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must be selected to add a block.");
		}
		if (game.getAdmin() != admin) {
			throw new InvalidInputException("Only the admin who created the game can add a block.");
		}
		List<Block> blocks = game.getBlocks();
		for (Block block : blocks) {
			if (block.getRed() == red && block.getGreen() == green && block.getBlue() == blue) {
				throw new InvalidInputException("A block with the same color already exists for the game.");
			}
		}
		try {
			new Block(red, green, blue, points, game);
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}
	}

	public static void deleteBlock(int id) throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to delete a block.");
		}
		Game game = Block223Application.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must be selected to delete a block.");
		}
		if (game.getAdmin() != admin) {
			throw new InvalidInputException("Only the admin who created the game can delete a block.");
		}
		Block block = game.findBlock(id);
		if (block != null) {
			block.delete();
		}
	}

	public static void updateBlock(int id, int red, int green, int blue, int points) throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to update a block.");
		}
		Game game = Block223Application.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must be selected to update a block.");
		}
		if (game.getAdmin() != admin) {
			throw new InvalidInputException("Only the admin who created the game can update a block.");
		}
		
		List<Block> blocks = game.getBlocks();
		for (Block block : blocks) {
			if (block.getRed() == red && block.getGreen() == green && block.getBlue() == blue) {
				if (block.getPoints() == points) {
					throw new InvalidInputException("A block with the same color already exists for the game.");
				}
			}
		}
		Block block = game.findBlock(id);
		if (block != null) {
			try {
				block.setRed(red);
				block.setGreen(green);
				block.setBlue(blue);
				block.setPoints(points);
				return;
			} catch (RuntimeException e) {
				throw new InvalidInputException(e.getMessage());
			}
			
		}
		throw new InvalidInputException("The block does not exist.");
	}

	public static void positionBlock(int id, int level, int gridHorizontalPosition, int gridVerticalPosition)
			throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to position a block.");
		}
		Game g = Block223Application.getCurrentGame();
		if (g == null) {
			throw new InvalidInputException("A game must be selected to position a block.");
		}
		if (!g.getAdmin().equals(admin)) {
			throw new InvalidInputException("Only the admin who created the game can position a block.");
		}
		Level levelObject;
		try {
			levelObject = g.getLevel(level);
		} catch (IndexOutOfBoundsException e) {
			throw new InvalidInputException("Level " + level + " does not exist for the game.");
		}
		if (g.getNrBlocksPerLevel() == levelObject.getBlockAssignments().size()) {
			throw new InvalidInputException("The number of blocks has reached the maximum number ("
					+ g.getNrBlocksPerLevel() + ") allowed for this game.");
		}
		for (BlockAssignment ba : levelObject.getBlockAssignments()) {
			if (ba.getGridHorizontalPosition() == gridHorizontalPosition
					&& ba.getGridVerticalPosition() == gridVerticalPosition) {
				throw new InvalidInputException("A block already exists at location " + gridHorizontalPosition + "/"
						+ gridVerticalPosition + ".");
			}
		}

		Block block = g.findBlock(id);
		if (block != null) {
			try {
				new BlockAssignment(gridHorizontalPosition, gridVerticalPosition, levelObject, block, g);
			} catch (RuntimeException e) {
				throw new InvalidInputException(e.getMessage());
			}
		} else {
			throw new InvalidInputException("The block does not exist.");
		}
	}

	public static void moveBlock(int level, int oldGridHorizontalPosition, int oldGridVerticalPosition,
			int newGridHorizontalPosition, int newGridVerticalPosition) throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to move a block.");
		}
		Game game = Block223Application.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must be selected to move a block.");
		}
		if (!game.getAdmin().equals(admin)) {
			throw new InvalidInputException("Only the admin who created the game can move a block.");
		}
		Level levelObject;
		try {
			levelObject = game.getLevel(level);
		} catch (IndexOutOfBoundsException e) {
			throw new InvalidInputException("Level " + level + " does not exist for the game.");
		}

		BlockAssignment blockAssignment = levelObject.findBlockAssignment(oldGridHorizontalPosition,
				oldGridVerticalPosition);
		if (blockAssignment == null) {
			throw new InvalidInputException("A block does not exist at location " + oldGridHorizontalPosition + "/"
					+ oldGridVerticalPosition + ".");
		}
		if (levelObject.findBlockAssignment(newGridHorizontalPosition, newGridVerticalPosition) != null) {
			throw new InvalidInputException("A block already exists at location " + newGridHorizontalPosition + "/"
					+ newGridVerticalPosition + ".");
		}

		try {
			blockAssignment.setGridHorizontalPosition(newGridHorizontalPosition);
			blockAssignment.setGridVerticalPosition(newGridVerticalPosition);
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}

	}

	public static void removeBlock(int level, int gridHorizontalPosition, int gridVerticalPosition)
			throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to remove a block.");
		}
		Game game = Block223Application.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must be selected to remove a block.");
		}
		if (game.getAdmin() != admin) {
			throw new InvalidInputException("Only the admin who created the game can remove a block.");
		}
		Level specificLevel = game.getLevel(level);
		BlockAssignment assignment = specificLevel.findBlockAssignment(gridHorizontalPosition, gridVerticalPosition);
		if (assignment != null) {
			assignment.delete();
		}
	}

	public static void saveGame() throws InvalidInputException {
		Block223 block223 = Block223Application.getBlock223();
		if (!(Block223Application.getCurrentUserRole() instanceof Admin)) {
			throw new InvalidInputException("Admin privileges are required to save a game.");
		}
		if (Block223Application.getCurrentGame() == null) {
			throw new InvalidInputException("A game must be selected to save it.");
		}
		if (Block223Application.getCurrentGame().getAdmin() != Block223Application.getCurrentUserRole()) {
			throw new InvalidInputException("Only the admin who created the game can save it.");
		}
		try {
			Block223Persistence.save(block223);
		} catch (RuntimeException e) {
			throw new InvalidInputException(e.getMessage());
		}

	}

	public static void register(String username, String playerPassword, String adminPassword)
			throws InvalidInputException {
		Block223 block223 = Block223Application.getBlock223();
		if ((Block223Application.getCurrentUserRole() instanceof Admin)
				|| (Block223Application.getCurrentUserRole() instanceof Player)) {
			throw new InvalidInputException("Cannot register a new user while a user is logged in.");
		}
		if (playerPassword.equals(adminPassword)) {
			throw new InvalidInputException("The passwords have to be different.");
		}

		try {
			Player player = new Player(playerPassword, block223);
			User user = new User(username, block223, player);
			if (adminPassword != null && !adminPassword.equals("")) {
				Admin admin = new Admin(adminPassword, block223);
				user.addRole(admin);
			}
			Block223Persistence.save(block223);
		} catch (RuntimeException e) {
			String error = e.getMessage();
			if (error.equals("Cannot create due to duplicate username")) {
				error = "The username has already been taken.";
			}
			throw new InvalidInputException(error);
		}
	}

	public static void login(String username, String password) throws InvalidInputException {
		if (Block223Application.getCurrentUserRole() != null) {
			throw new InvalidInputException("Cannot login a user while a user is already logged in.");
		}
		User user = User.getWithUsername(username);
		if (user == null) {
			throw new InvalidInputException("The username and password do not match.");
		}
		List<UserRole> roles = user.getRoles();

		String pws = "";
		for (UserRole role : roles) {
			String rolePassword = role.getPassword();
			pws = pws + rolePassword + " / ";
			if (rolePassword.equals(password)) {
				Block223Application.setCurrentUserRole(role);
				Block223Application.setCurrentUser(user);
				Block223Application.resetBlock223();
				return;
			}
		}
		throw new InvalidInputException("The username and password do not match.");
	}

	public static void logout() {
		Block223Application.setCurrentUserRole(null);
		Block223Application.setCurrentUser(null);
	}

	public void movePaddle(double displacement) {
		ParticularGame currentGame = Block223Application.getCurrentParticularGame();
		int levelNumber = currentGame.getCurrentLevel();
		ParticularLevel level = currentGame.getParticularLevel(levelNumber);
		ParticularPaddle paddle = level.getParticularPaddle();
		
		double currentPosition = paddle.getPosition() + displacement;
		if (currentPosition > Game.PLAY_AREA_SIDE - paddle.getLength() / 2) {
			paddle.setPosition(Game.PLAY_AREA_SIDE - paddle.getLength() / 2);
		} else if (currentPosition < paddle.getLength() / 2) {
			paddle.setPosition(paddle.getLength() / 2);
		} else {
			paddle.setPosition(currentPosition);
		}
	}

	// ****************************
	// Query methods
	// ****************************
	public static List<TOGame> getDesignableGames() throws InvalidInputException {
		Block223 block223 = Block223Application.getBlock223();
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to access game information.");
		}
		List<TOGame> result = new ArrayList<>();
		List<Game> games = block223.getGames();
		for (Game game : games) {
			if (game.getAdmin().equals(admin)) {
				result.add(new TOGame(game.getName(), game.getLevels().size(), game.getNrBlocksPerLevel(),
						game.getBall().getMinBallSpeedX(), game.getBall().getMinBallSpeedY(),
						game.getBall().getBallSpeedIncreaseFactor(), game.getPaddle().getMaxPaddleLength(),
						game.getPaddle().getMinPaddleLength()));
			}
		}
		return result;
	}

	public static TOGame getCurrentDesignableGame() throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to access game information.");
		}
		Game game = Block223Application.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must be selected to access its information.");
		}
		if (!game.getAdmin().equals(admin)) {
			throw new InvalidInputException("Only the admin who created the game can access its information.");
		}

		return new TOGame(game.getName(), game.getLevels().size(), game.getNrBlocksPerLevel(),
				game.getBall().getMinBallSpeedX(), game.getBall().getMinBallSpeedY(),
				game.getBall().getBallSpeedIncreaseFactor(), game.getPaddle().getMaxPaddleLength(),
				game.getPaddle().getMinPaddleLength());
	}

	public static List<TOBlock> getBlocksOfCurrentDesignableGame() throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to access game information.");
		}
		Game game = Block223Application.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must be selected to access its information.");
		}
		if (!game.getAdmin().equals(admin)) {
			throw new InvalidInputException("Only the admin who created the game can access its information.");
		}

		List<TOBlock> result = new ArrayList<>();
		for (Block block : game.getBlocks()) {
			result.add(
					new TOBlock(block.getId(), block.getRed(), block.getGreen(), block.getBlue(), block.getPoints()));
		}

		return result;
	}

	public static TOBlock getBlockOfCurrentDesignableGame(int id) throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to access game information.");
		}
		Game game = Block223Application.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must be selected to access its information.");
		}
		if (!game.getAdmin().equals(admin)) {
			throw new InvalidInputException("Only the admin who created the game can access its information.");
		}
		Block block = game.findBlock(id);
		if (block != null) {
			return new TOBlock(block.getId(), block.getRed(), block.getGreen(), block.getBlue(), block.getPoints());
		}

		throw new InvalidInputException("The block does not exist.");
	}

	public static List<TOGridCell> getBlocksAtLevelOfCurrentDesignableGame(int level) throws InvalidInputException {
		UserRole role = Block223Application.getCurrentUserRole();
		Admin admin;
		if (role instanceof Admin) {
			admin = (Admin) role;
		} else {
			throw new InvalidInputException("Admin privileges are required to access game information.");
		}
		Game game = Block223Application.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must be selected to access its information.");
		}
		if (!game.getAdmin().equals(admin)) {
			throw new InvalidInputException("Only the admin who created the game can access its information.");
		}

		Level l;
		try {
			l = game.getLevel(level);
		} catch (IndexOutOfBoundsException e) {
			throw new InvalidInputException("Level " + level + " does not exist for the game.");
		}

		List<TOGridCell> result = new ArrayList<>();
		for (BlockAssignment ba : l.getBlockAssignments()) {
			result.add(new TOGridCell(ba.getGridHorizontalPosition(), ba.getGridVerticalPosition(),
					ba.getBlock().getId(), ba.getBlock().getRed(), ba.getBlock().getGreen(), ba.getBlock().getBlue(),
					ba.getBlock().getPoints()));
		}

		return result;
	}

	public static TOUserMode getUserMode() {
		UserRole role = Block223Application.getCurrentUserRole();
		if (role == null) {
			return new TOUserMode(Mode.None);
		}
		if (role instanceof Player) {
			return new TOUserMode(Mode.Play);
		}
		if (role instanceof Admin) {
			return new TOUserMode(Mode.Design);
		}
		return new TOUserMode(Mode.None);
	}

}