/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4262.30c9ffc7c modeling language!*/

package ca.mcgill.ecse223.block.controller;

// line 21 "../../../../../Block223TransferObjects.ump"
public class TOParticularLevel
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //TOParticularLevel Attributes
  private double ballPositionX;
  private double ballPositionY;
  private double ballSpeedX;
  private double ballSpeedY;
  private double paddleLength;
  private double paddlePosition;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public TOParticularLevel(double aBallPositionX, double aBallPositionY, double aBallSpeedX, double aBallSpeedY, double aPaddleLength, double aPaddlePosition)
  {
    ballPositionX = aBallPositionX;
    ballPositionY = aBallPositionY;
    ballSpeedX = aBallSpeedX;
    ballSpeedY = aBallSpeedY;
    paddleLength = aPaddleLength;
    paddlePosition = aPaddlePosition;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setBallPositionX(double aBallPositionX)
  {
    boolean wasSet = false;
    ballPositionX = aBallPositionX;
    wasSet = true;
    return wasSet;
  }

  public boolean setBallPositionY(double aBallPositionY)
  {
    boolean wasSet = false;
    ballPositionY = aBallPositionY;
    wasSet = true;
    return wasSet;
  }

  public boolean setBallSpeedX(double aBallSpeedX)
  {
    boolean wasSet = false;
    ballSpeedX = aBallSpeedX;
    wasSet = true;
    return wasSet;
  }

  public boolean setBallSpeedY(double aBallSpeedY)
  {
    boolean wasSet = false;
    ballSpeedY = aBallSpeedY;
    wasSet = true;
    return wasSet;
  }

  public boolean setPaddleLength(double aPaddleLength)
  {
    boolean wasSet = false;
    paddleLength = aPaddleLength;
    wasSet = true;
    return wasSet;
  }

  public boolean setPaddlePosition(double aPaddlePosition)
  {
    boolean wasSet = false;
    paddlePosition = aPaddlePosition;
    wasSet = true;
    return wasSet;
  }

  public double getBallPositionX()
  {
    return ballPositionX;
  }

  public double getBallPositionY()
  {
    return ballPositionY;
  }

  public double getBallSpeedX()
  {
    return ballSpeedX;
  }

  public double getBallSpeedY()
  {
    return ballSpeedY;
  }

  public double getPaddleLength()
  {
    return paddleLength;
  }

  public double getPaddlePosition()
  {
    return paddlePosition;
  }

  public void delete()
  {}


  public String toString()
  {
    return super.toString() + "["+
            "ballPositionX" + ":" + getBallPositionX()+ "," +
            "ballPositionY" + ":" + getBallPositionY()+ "," +
            "ballSpeedX" + ":" + getBallSpeedX()+ "," +
            "ballSpeedY" + ":" + getBallSpeedY()+ "," +
            "paddleLength" + ":" + getPaddleLength()+ "," +
            "paddlePosition" + ":" + getPaddlePosition()+ "]";
  }
}